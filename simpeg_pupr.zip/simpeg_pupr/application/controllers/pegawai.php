<?php

/**
* 
*/
class Pegawai extends CI_controller
{
	
	function __construct()
	{
	 parent:: __construct();
	 $this->load->helper('url');
	 if($this->session->userdata('pegawai') != TRUE){
      redirec(base_url(''));
      exit;
	 };
	}

	public function index()
	{
	 $x = array('judul' =>'Halaman Administrator');
	 $this->load->view('admin/home', $data);
	 tpl('admin/home',$x);
	}
}