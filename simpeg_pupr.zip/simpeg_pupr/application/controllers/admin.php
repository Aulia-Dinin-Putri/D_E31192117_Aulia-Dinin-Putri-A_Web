<?php
 if ( ! defined('BASEPATH')) exit(header('Location:../'));
class Admin extends CI_controller
{
  function __construct()
  {
   parent:: __construct();
   // error_reporting(0);
    if($this->session->userdata('admin') != TRUE){
      redirect(base_url(''));
      exit;
    };
   $this->load->model('m_admin');
  }

  public function index()
  {
      $x = array('judul' =>'Halaman Administrator');
      /*$table_to_count = ['pegawai','']
      for ($i=0; $i <=count($table_to_count) ; $i++) { 
        $count_data[i]=$this->m_admin->count_data($table);
      }*/
      tpl('admin/home',$x);
  }
  
  public function menu_pengangkatan()
  {
      $x = array('judul' =>'Menu Pengangkatan');
      /*$table_to_count = ['pegawai','']
      for ($i=0; $i <=count($table_to_count) ; $i++) { 
        $count_data[i]=$this->m_admin->count_data($table);
      }*/
      tpl('admin/menu_pengangkatan',$x);
  }

  public function jabatan()
  {
   $x = array('judul' =>'Data Jabatan', 
              'data'=>$this->db->get('jabatan')->result_array()); 
   tpl('admin/jabatan',$x);
  }

  public function jabatan_tambah()
  {
  $x = array('judul'        => 'Tambah Data Jabatan' ,
              'aksi'        => 'tambah',
              'nama_pegawai'=> "",
			  'nama_jabatan'=> "",
              'golongan'    => "",
              'tunjangan'   => ""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nama_pegawai'=>$this->input->post('nama_pegawai'),
		'nama_jabatan'=>$this->input->post('nama_jabatan'),
        'golongan'    =>$this->input->post('golongan'),
        'tunjangan'         =>$this->input->post('tunjangan'));
      $cek=$this->db->insert('jabatan',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/jabatan'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/jabatan_form',$x);
    }
  }
    
  public function jabatan_edit($id='')
  {
  $sql=$this->db->get_where('jabatan',array('id_jabatan'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Jabatan' ,
              'aksi'        =>'tambah',
        'nama_pegawai'=>$sql['nama_pegawai'],
		'nama_jabatan'=>$sql['nama_jabatan'],
        'golongan'    =>$sql['golongan'],
        'tunjangan'         =>$sql['tunjangan']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nama_pegawai'=>$this->input->post('nama_pegawai'),
		'nama_jabatan'=>$this->input->post('nama_jabatan'),
        'golongan'    =>$this->input->post('golongan'),
        'tunjangan'         =>$this->input->post('tunjangan'));
      $cek=$this->db->update('jabatan',$inputData,array('id_jabatan'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/jabatan'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/jabatan_form',$x);
    }
  }

  
  public function jabatan_hapus($id='')
  {
   $cek=$this->db->delete('jabatan',array('id_jabatan'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/jabatan'));
   }
  }

  public function pegawai($value='')
  {
   $x = array('judul' =>':: Data Pegawai ::',
              'data'  =>$this->m_admin->pegawai(),);
     tpl('admin/pegawai',$x);
  }

  public function ls_pegawai($value='')
  {
   $data=$this->m_admin->pegawai()->row_array();
   echo json_encode($data);
  }

  public function pegawai_tambah($value='')
  {
   $x = array(
    'judul' =>'Tambah Data Pegawai' , 
    'aksi'  =>'Tambah',
    'jabatan'=>$this->db->get('jabatan')->result_array(),
    'id_jabatan'=>'',
    'nip'=>'',
    'nama'=>'',
    'jk'=>'',
    'foto'=>'',
    'agama'=>'',
    'pendidikan'=>'',
    'status_kep'=>'',
    'alamat'=>'',
    'username'=>''
  );
    
   if (isset($_POST['kirim'])) {
      
      $config['upload_path'] = './template/data/'; 
      $config['allowed_types'] = 'bmp|jpg|png';  
      $config['file_name'] = 'foto_'.time();  
      $this->load->library('upload', $config);
      $this->upload->initialize($config);
      if($this->upload->do_upload('gambar')){
        $SQLinsert=array(
        'id_jabatan'=>$this->input->post('id_jabatan'),
        'nip'=>$this->input->post('nip'),
        'nama'=>$this->input->post('nama'),
        'jk'=>$this->input->post('jk'),
        'foto'=>$this->upload->file_name,
        'agama'=>$this->input->post('agama'),
        'pendidikan'=>$this->input->post('pendidikan'),
        'status_kep'=>$this->input->post('status_kep'),
        'alamat'=>$this->input->post('alamat'),
        'username'=>$this->input->post('username'),
        'password'=>md5($this->input->post('password'))
        );

        $cek=$this->db->insert('pegawai',$SQLinsert);
        if($cek){
            $pesan='<div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                        <h4><i class="icon fa fa-check"></i> Success!</h4>
                       Data Berhasil Di Tambahkan.
                      </div>';
            $this->session->set_flashdata('pesan',$pesan);
            redirect(base_url('admin/pegawai'));
        }else{
         echo "QUERY SQL ERROR";
        }
      }else{
        echo $this->upload->display_errors();
      }
    }else{
      tpl('admin/pegawai_form',$x);
    } 
 
  }

  public function pegawai_edit($id='')
  {

  $data=$this->db->get_where('pegawai',array('id_pegawai'=>$id))->row_array();  
  $x = array(
    'aksi'=>'edit',
    'judul' =>'Tambah Data Pegawai' ,
    'jabatan'=>$this->db->get('jabatan')->result_array(),
    'id_jabatan'=>$data['id_jabatan'],
    'nip'=>$data['nip'],
    'nama'=>$data['nama'],
    'jk'=>$data['jk'],
    'foto'=>$data['foto'],
    'agama'=>$data['agama'],
    'pendidikan'=>$data['pendidikan'],
    'status_kep'=>$data['status_kep'],
    'alamat'=>$data['alamat'],
    'username'=>$data['username']
  );
    
  if (isset($_POST['kirim'])) {     
    if(empty($_FILES['gambar']['name'])){
      $SQLinsert=array(
      'id_jabatan'=>$this->input->post('id_jabatan'),
      'nip'=>$this->input->post('nip'),
      'nama'=>$this->input->post('nama'),
      'jk'=>$this->input->post('jk'),
      //'foto'=>$this->upload->file_name,
      'agama'=>$this->input->post('agama'),
      'pendidikan'=>$this->input->post('pendidikan'),
      'status_kep'=>$this->input->post('status_kep'),
      'alamat'=>$this->input->post('alamat'),
      'username'=>$this->input->post('username'),
      //'password'=>md5($this->input->post('password'))
      );

      $this->db->update('pegawai',$SQLinsert,array('id_pegawai'=>$id));
      $pesan='<div class="alert alert-success alert-dismissible">
                      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                      <h4><i class="icon fa fa-check"></i> Success!</h4>
                     Data Berhasil Di Edit.
                    </div>';
      $this->session->set_flashdata('pesan',$pesan);
      redirect(base_url('admin/pegawai'));
    }else{
        $config['upload_path'] = './template/data/'; 
        $config['allowed_types'] = 'bmp|jpg|png';  
        $config['file_name'] = 'foto_'.time();  
        $this->load->library('upload', $config);
        $this->upload->initialize($config);
        if($this->upload->do_upload('gambar')){
          $SQLinsert=array(
          'id_jabatan'=>$this->input->post('id_jabatan'),
          'nip'=>$this->input->post('nip'),
          'nama'=>$this->input->post('nama'),
          'jk'=>$this->input->post('jk'),
          'foto'=>$this->upload->file_name,
          'agama'=>$this->input->post('agama'),
          'pendidikan'=>$this->input->post('pendidikan'),
          'status_kep'=>$this->input->post('status_kep'),
          'alamat'=>$this->input->post('alamat'),
          'username'=>$this->input->post('username'),
          //'password'=>md5($this->input->post('password'))
          );
          $cek=$this->db->update('pegawai',$SQLinsert,array('id_pegawai'=>$id));
          if($cek){
              $pesan='<div class="alert alert-success alert-dismissible">
                          <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                          <h4><i class="icon fa fa-check"></i> Success!</h4>
                         Data Berhasil Di Edit.
                        </div>';
              $this->session->set_flashdata('pesan',$pesan);
              redirect(base_url('admin/pegawai'));
          }else{
           echo "QUERY SQL ERROR";
          }
        }else{
          echo $this->upload->display_errors();
        }
     }
    }else{
      tpl('admin/pegawai_form',$x);
    }
  }
   
  public function pegawai_hapus($id='')
  {
    $foto=$this->db->get_where('pegawai',array('id_pegawai'=>$id))->row_array();
    if($foto['foto'] != ""){ @unlink('template/data/'.$foto['foto']); }else{ }

    $cek=$this->db->delete('pegawai',array('id_pegawai'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pegawai'));
   }
  } 


//bagian absensi  

  public function cari_pegawai()
  {
  if($this->session->userdata('level') == "pegawai"){  

     $id = $this->session->userdata('id_pegawai');  
     $x['pegawai']=$this->db->get_where('pegawai',array('id_pegawai'=>$id));
     $this->load->view('admin/data_pegawai',$x);

  }elseif($this->session->userdata('level') == "admin"){

     $id=$this->input->post('cari_p');  
     $x['pegawai']=$this->db->get_where('pegawai',array('id_pegawai'=>$id));
     $this->load->view('admin/data_pegawai',$x);

  }elseif($this->session->userdata('level') == "user"){
     $id=$this->input->post('cari_p');  
     $x['pegawai']=$this->db->get_where('pegawai',array('id_pegawai'=>$id));
     $this->load->view('admin/data_pegawai',$x);
  }
}

  public function cari_tpp()
  {
  $id=$this->input->post('cari_p');  
  $x['data']=$this->m_admin->tpp_id($id);
  $this->load->view('admin/tpp',$x);
  }

  public function absensi()
  {
    $id   = ($this->session->userdata('level') == "pegawai") ? $this->session->userdata('id_pegawai') : $this->session->userdata('id_admin');
    $data = ($this->session->userdata('level') == "pegawai") ? $this->m_admin->cari_pegawai($id) : $this->m_admin->pegawai();
    $x = array('judul' =>'Absensi Pegawai',
              'data'  =>$data); 
    tpl('admin/absensi',$x);
  }


public function aksi_abs()
{
 
  $id_pegawai= $this->input->post('id_pegawai');
  $bulan     = $this->input->post('bulan');
  
  $tanggal= date('Y-m-d');
  $hadir  = $this->input->post('hadir');
  $izin   = $this->input->post('izin');
  $tidak_hadir=$this->input->post('tidak_hadir'); 
  
  $hitung=$hadir+$izin+$tidak_hadir;
if ($hitung > 31) {
   buat_alert('Data Hadir Izin Dan Tidak Hadir Yang Anda Entrikan Lebih Dari 30');
}else{
  $cek=$this->db->query("SELECT * from absen where id_pegawai='$id_pegawai'
                          AND bulan='$bulan'");
  if ($cek->num_rows() > 0) {
    buat_alert('Data Absensi Sudah Ada .. Silahkan Pilih Abasensi Dengan Bulan Yang Lain');
  }else{
    
    if($hadir >= 10 ){
      $kehadiran='30%';
    }else if($hadir >= 20){
      $kehadiran='10%';
      if($hadir > 25){
        $kehadiran='5%';
      }
    }else if($hadir < 10) {
      $kehadiran='50%';
    }else{
      $kehadiran='0%';
    }
  
    $hasil=$this->m_admin->cari_jabatan($id_pegawai)->row_array();
    $tunjangan=$hasil['tunjangan']-$kehadiran;
    $sql = array(
        'id_pegawai'=>$id_pegawai,
        'jumlah_tpp'=>$tunjangan,
        'jumlah_potongan'=>$kehadiran,
        'bulan_t'=>$bulan,
        'tahun'=>date("Y"),
        'tgl'=>date("Y-m-d"));
    $this->db->insert('tpp',$sql);
    $data = array(
                   'id_pegawai' =>$id_pegawai, 
                   'hadir'      =>$hadir,
                   'izin'       =>$izin,
                   'tidak_hadir'=>$tidak_hadir,
                   'bulan'=>$this->input->post('bulan'),
                   'tanggal'    =>date('Y-m-d'));
     $this->db->insert('absen',$data);
    buat_alert('Data Absensi Berhasil Di Tambahkan ..');
 }
}


}

//bagian gaji

public function cari_gaji_p()
{

$id=$this->input->post('cari_p');  
$x['pegawai']=$this->m_admin->cari_pegawai($id);
$this->load->view('admin/gaji_form',$x);

}

public function gaji_pegawai()
{
 $x['judul'] ="Data Gaji Pegawai";
 $x['data']  =$this->m_admin->gaji_pegawai(); 
 tpl('admin/gaji',$x);
}


public function gaji_tambah()
{
 if (isset($_POST['kirim'])) {
    $id_pegawai=$this->input->post('id_pegawai');
    $cek=$this->db->get_where('gaji',array('id_pegawai'=>$id_pegawai));
    if($cek->num_rows() > 0){
     buat_alert('Maaf Data Gaji Pada Pegawai Ini Telah Ada');
    }else{
    $Sql=array(
    'id_pegawai'=>$this->input->post('id_pegawai'),
    'jumlah'    =>$this->input->post('jumlah'));
    $this->db->insert('gaji',$Sql);
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Penggajian Berhasil Di Tambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/gaji_pegawai'));
  }
}else{
   $x['judul'] ="Data Gaji Pegawai";
   $x['data']  =$this->m_admin->gaji_set(); 
   tpl('admin/set_gaji',$x);
  } 
 
}


public function gaji_hapus($id='')
{
   $cek=$this->db->delete('gaji',array('id_gaji'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/gaji_pegawai'));
   }
}

public function tpp()
{
 $x = array('judul' =>'Tunjangan Pendapatan Pegawai',
            'data'=>$this->m_admin->pegawai_data()); 
  tpl('admin/tpp_set',$x);
}

public function tpp_hapus($id)
{
   $cek=$this->db->delete('tpp',array('id_pegawai'=>$id));
   $cek=$this->db->delete('absen',array('id_pegawai'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/tpp'));

}
}

public function tpp_print($id='')
{
 $x = array('judul' =>'Print TPP Data',
             'data'=>$this->m_admin->tpp_print($id)->result_array()); 
 $this->load->view('laporan/print_tpp',$x);
}



//bagian Login Administrais User..


public function user_admin($value='')
{
$x = array('judul' =>'Data Hak Akses',
            'data' =>$this->db->get('admin')); 
 tpl('admin/user_admin',$x);
}

public function user_admin_tambah()
{
if(isset($_POST['kirim'])){
 $data = array(
                'username' =>$this->input->post('username'),
                'password' =>md5($this->input->post('password')),
                'nama' =>$this->input->post('nama'),
                'level' =>$this->input->post('level'), );
 $cek =$this->db->insert('admin',$data);
 if($cek){
      $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Edit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/user_admin'));
 }else{
  buat_alert('SYSTEM ERROR');
 }
 
}else{
$x = array('judul' =>'Data Hak Akses',
           'username' =>'',
           'nama'     =>'',
           'data' =>$this->db->get('admin')); 
 tpl('admin/user_admin_form',$x);
}
}

public function user_admin_edit($id='')
{
$sql=$this->db->get_where('admin',array('id_admin'=>$id))->row_array();  
if(isset($_POST['kirim'])){
 $data = array(
                'username' =>$this->input->post('username'),
                'password' =>md5($this->input->post('password')),
                'nama' =>$this->input->post('nama'),
                'level' =>$this->input->post('level'),);
 $cek =$this->db->update('admin',$data,array('id_admin' =>$id));
 if($cek){
      $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Edit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/user_admin'));
 }else{
  buat_alert('SYSTEM ERROR');
 }
}else{
$x = array('judul' =>'Edit Data Hak Akses',
            'username' =>$sql['username'],
            'nama'     =>$sql['nama'],
            'data' =>$this->db->get('admin')); 
 tpl('admin/user_admin_form',$x);
}
}
public function user_admin_hapus($id='')
{
 if($this->session->userdata('id_admin') == $id){
  $pesan='<div class="alert alert-danger alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
              Anda Tidak Bisa Menghapus Anda Sendiri.
              </div>';
 $this->session->set_flashdata('pesan',$pesan);
 redirect(base_url('admin/user_admin'));

 }else{ 
 $this->db->delete('admin',array('id_admin' =>$id));
  $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
 $this->session->set_flashdata('pesan',$pesan);
 redirect(base_url('admin/user_admin'));
}
}

public function profil()
{
 if (isset($_POST['kirim'])) {
     $data = array('password' => md5($this->input->post('password')),
                    'nama'    => $this->input->post('nama'), );
      $this->db->update('admin',$data,array('id_admin'=>$this->session->userdata('id_admin')));
      $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Edit Password Anda Adalah '.$this->input->post('password').' .
              </div>';
   $this->session->set_flashdata('pesan',$pesan);
   redirect(base_url('admin/profil'));   
  }else{
   $x = array('judul' =>'Ubah Password Administrator', 
               'data' =>$this->db->get_where('admin',array('id_admin'=>$this->session->userdata('id_admin')))->row_array(),
             );
   tpl('admin/ubah_password',$x);            
  } 

}


public function profil_pegawai($value='')
{
  if(isset($_POST['kirim'])){
    $vaPassword = array('password'=>$this->input->post('password'));
    $vaWhere    = array('id_pegawai'=>$this->session->userdata('id_pegawai'));
    if(isset($_FILES['gambar']['name'])){
      $config['upload_path'] = './template/data/'; 
      $config['allowed_types'] = 'bmp|jpg|png';  
      $config['file_name'] = 'foto_'.time();  
      $this->load->library('upload', $config);
      $this->upload->initialize($config);
      if($this->upload->do_upload('gambar')){
        $vaFoto     = array('foto'=>$this->upload->file_name);
        $this->db->update('pegawai',$vaFoto,$vaWhere);  
      }else{
        echo $this->upload->display_errors();
      }
    }
    
    if($this->input->post('password') !== ""){
      $this->db->update('pegawai',$vaPassword,$vaWhere);  
    }
    
    $sql=array(
      'nip'=>$this->input->post('nip'),
      'nama'=>$this->input->post('nama'),
      'jk'=>$this->input->post('jk'),
      'agama'=>$this->input->post('agama'),
      'pendidikan'=>$this->input->post('pendidikan'),
      'alamat'=>$this->input->post('alamat'),
      'username'=>$this->input->post('username'),
    );
    
    
    $cek=$this->db->update('pegawai',$sql,$vaWhere);
    if($cek){
       $pesan='<div class="alert alert-success alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                  <h4><i class="icon fa fa-check"></i> Success!</h4>
                 Data Berhasil Di Edit.
                </div>';
      $this->session->set_flashdata('pesan',$pesan);
      redirect(base_url('admin/profil_pegawai'));
    }else{
      buat_alert('ERROR');
    }
  }else{
    $data=$this->db->get_where('pegawai',array('id_pegawai' =>$this->session->userdata('id_pegawai')))->row_array();
    $x = array(
       'judul' =>'.:: Edit Profil Anda ::.',
       'aksi'=>'edit',
       'foto'=>$data['foto'],
       'nama'=>$data['nama'],
       'jk'=>$data['jk'],
       'alamat'=>$data['alamat'],
       'nip'=>$data['nip'],
       'agama'=>$data['agama'],
       'pendidikan'=>$data['pendidikan'],
       'username'=>$data['username']);
      tpl('admin/profil_pegawai',$x);
  }
} 


public function penghargaan()
  {
   $x = array('judul' =>'Data Penghargaan', 
              'data'=>$this->db->get('penghargaan')->result_array()); 
   tpl('admin/penghargaan',$x);
  }

  public function penghargaan_tambah()
  {
  $x = array('judul'        => 'Tambah Data Penghargaan' ,
              'aksi'        => 'tambah',
              'nama_pegawai'=> "",
			  'no_skpenghargaan'=> "",
              'tgl_skpenghargaan'=> "",
              'asal_skpenghargaan'=> ""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nama_pegawai'=>$this->input->post('nama_pegawai'),
		'no_skpenghargaan'=>$this->input->post('no_skpenghargaan'),
        'tgl_skpenghargaan'=>$this->input->post('tgl_skpenghargaan'),
        'asal_skpenghargaan'=>$this->input->post('asal_skpenghargaan'));
      $cek=$this->db->insert('penghargaan',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penghargaan'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/penghargaan_form',$x);
    }
  }
    
  public function penghargaan_edit($id='')
  {
  $sql=$this->db->get_where('penghargaan',array('id_penghargaan'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Penghargaan' ,
              'aksi'        =>'tambah',
        'nama_pegawai'=>$sql['nama_pegawai'],
		'no_skpenghargaan'=>$sql['no_skpenghargaan'],
        'tgl_skpenghargaan'    =>$sql['tgl_skpenghargaan'],
        'asal_skpenghargaan'         =>$sql['asal_skpenghargaan']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nama_pegawai'=>$this->input->post('nama_pegawai'),
		'no_skpenghargaan'=>$this->input->post('no_skpenghargaan'),
        'tgl_skpenghargaan'    =>$this->input->post('tgl_skpenghargaan'),
        'asal_skpenghargaa'         =>$this->input->post('asal_skpenghargaa'));
      $cek=$this->db->update('penghargaan',$inputData,array('id_penghargaan'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penghargaan'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/penghargaan_form',$x);
    }
  }

  
  public function penghargaan_hapus($id='')
  {
   $cek=$this->db->delete('penghargaan',array('id_penghargaan'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penghargaan'));
   }
  }

/*public function penggajian()
  {
   $x = array('judul' =>'Data Penggajian', 
              'data'=>$this->db->get('penggajian')->result_array()); 
   tpl('admin/penggajian',$x);
  }

  public function penggajian_tambah()
  {
  $x = array('judul'        => 'Tambah Data Penggajian' ,
              'aksi'        => 'tambah',
              'nip'=> "",
			  'nama'=> "",
			  'pejabat_ygmenetapkan'=> "",
              'nomor'=> "",
			  'tgl_gaji'=> "",
			  'gaji_pokok'=> "",
			  'tmt_kgb'=> "",
			  'tahun'=> "",
              'bulan'=> ""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
		'nama'=>$this->input->post('nama'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'nomor'=>$this->input->post('nomor'),
        'tgl_gaji'=>$this->input->post('tgl_gaji'),
		'gaji_pokok'=>$this->input->post('gaji_pokok'),
		'tmt_kgb'=>$this->input->post('tmt_kgb'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'));
      $cek=$this->db->insert('penggajian',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penggajian'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/penggajian_form',$x);
    }
  }
    
  public function penggajian_edit($id='')
  {
  $sql=$this->db->get_where('penggajian',array('id_penggajian'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Penggajian' ,
              'aksi'        =>'tambah',
        'nip'=>$sql['nip'],
		'nama'=>$sql['nama'],
		'pejabat_ygmenetapkan'=>$sql['pejabat_ygmenetapkan'],
        'nomor'=>$sql['nomor'],
		'tgl_gaji'=>$sql['tgl_gaji'],
		'gaji_pokok'=>$sql['gaji_pokok'],
		'tmt_kgb'=>$sql['tmt_kgb'],
		'tahun'=>$sql['tahun'],
        'bulan'=>$sql['bulan']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
		'nama'=>$this->input->post('nama'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'nomor'=>$this->input->post('nomor'),
        'tgl_gaji'=>$this->input->post('tgl_gaji'),
		'gaji_pokok'=>$this->input->post('gaji_pokok'),
		'tmt_kgb'=>$this->input->post('tmt_kgb'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'));
      $cek=$this->db->update('penggajian',$inputData,array('id_penggajian'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penggajian'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/penggajian_form',$x);
    }
  }

  
  public function penggajian_hapus($id='')
  {
   $cek=$this->db->delete('penggajian',array('id_penggajian'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/penggajian'));
   }
  }

*/

public function pengangkatancpns()
  {
   $x = array('judul' =>'Data Pengangkatan CPNS', 
              'data'=>$this->db->get('pengangkatancpns')->result_array()); 
   tpl('admin/pengangkatancpns',$x);
  }

  public function pengangkatancpns_tambah()
  {
  $x = array('judul'        => 'Tambah Data Pengangkatan CPNS' ,
              'aksi'        => 'tambah',
              'tgl_persetujuan_bakn'=> "",
			  'nama'=> "",
			  'no_nota_persetujuan_bakn'=> "",
			  'pejabat_ygmenetapkan'=> "",
              'no_sk_cpns'=> "",
			  'tgl_sk_cpns'=> "",
			  'gaji'=> "",
			  'ijazah'=> "",
			  'ijazah_tahun'=> "",
			  'gol_ruang'=> "",
			  'tmt_cpns'=> "",
			  'tahun'=> "",
			  'bulan'=> "",
			  'jabatan'=> "",
			  'opd'=> "",
			  'tmt_spmt'=> "",
			  'tahun_tambah_mk'=> "",
              'bulan_tambah_mk'=> ""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'tgl_persetujuan_bakn'=>$this->input->post('tgl_persetujuan_bakn'),
		'nama'=>$this->input->post('nama'),
		'no_nota_persetujuan_bakn'=>$this->input->post('no_nota_persetujuan_bakn'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'no_sk_cpns'=>$this->input->post('no_sk_cpns'),
		'tgl_sk_cpns'=>$this->input->post('tgl_sk_cpns'),
        'gaji'=>$this->input->post('gaji'),
		'ijazah'=>$this->input->post('ijazah'),
		'ijazah_tahun'=>$this->input->post('ijazah_tahun'),
		'gol_ruang'=>$this->input->post('gol_ruang'),
		'tmt_cpns'=>$this->input->post('tmt_cpns'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'),
		'jabatan'=>$this->input->post('jabatan'),
		'opd'=>$this->input->post('opd'),
		'tmt_spmt'=>$this->input->post('tmt_spmt'),
		'tahun_tambah_mk'=>$this->input->post('tahun_tambah_mk'),
		'bulan_tambah_mk'=>$this->input->post('bulan_tambah_mk'));
      $cek=$this->db->insert('pengangkatancpns',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatancpns'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pengangkatancpns_form',$x);
    }
  }
    
  public function pengangkatancpns_edit($id='')
  {
  $sql=$this->db->get_where('pengangkatancpns',array('id_angkat_cpns'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Pengangkatan CPNS' ,
              'aksi'        =>'tambah',
        'tgl_persetujuan_bakn'=>$sql['tgl_persetujuan_bakn'],
		'nama'=>$sql['nama'],
		'no_nota_persetujuan_bakn'=>$sql['no_nota_persetujuan_bakn'],
		'pejabat_ygmenetapkan'=>$sql['pejabat_ygmenetapkan'],
        'no_sk_cpns'=>$sql['no_sk_cpns'],
		'tgl_sk_cpns'=>$sql['tgl_sk_cpns'],
		'gaji'=>$sql['gaji'],
		'ijazah'=>$sql['ijazah'],
		'ijazah_tahun'=>$sql['ijazah_tahun'],
		'gol_ruang'=>$sql['gol_ruang'],
		'tmt_cpns'=>$sql['tmt_cpns'],
		'tahun'=>$sql['tahun'],
		'bulan'=>$sql['bulan'],
		'jabatan'=>$sql['jabatan'],
		'opd'=>$sql['opd'],
		'tmt_spmt'=>$sql['tmt_spmt'],
		'tahun_tambah_mk'=>$sql['tahun_tambah_mk'],
        'bulan_tambah_mk'=>$sql['bulan_tambah_mk']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'tgl_persetujuan_bakn'=>$this->input->post('tgl_persetujuan_bakn'),
		'nama'=>$this->input->post('nama'),
		'no_nota_persetujuan_bakn'=>$this->input->post('no_nota_persetujuan_bakn'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'no_sk_cpns'=>$this->input->post('no_sk_cpns'),
		'tgl_sk_cpns'=>$this->input->post('tgl_sk_cpns'),
        'gaji'=>$this->input->post('gaji'),
		'ijazah'=>$this->input->post('ijazah'),
		'ijazah_tahun'=>$this->input->post('ijazah_tahun'),
		'gol_ruang'=>$this->input->post('gol_ruang'),
		'tmt_cpns'=>$this->input->post('tmt_cpns'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'),
		'jabatan'=>$this->input->post('jabatan'),
		'opd'=>$this->input->post('opd'),
		'tmt_spmt'=>$this->input->post('tmt_spmt'),
		'tahun_tambah_mk'=>$this->input->post('tahun_tambah_mk'),
		'bulan_tambah_mk'=>$this->input->post('bulan_tambah_mk'));
      $cek=$this->db->update('pengangkatancpns',$inputData,array('id_angkat_cpns'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatancpns'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pengangkatancpns_form',$x);
    }
  }

  
  public function pengangkatancpns_hapus($id='')
  {
   $cek=$this->db->delete('pengangkatancpns',array('id_angkat_cpns'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatancpns'));
   }
  }
  
  
  
  
  
  
  public function pengangkatanpns()
  {
   $x = array('judul' =>'Data Pengangkatan PNS', 
              'data'=>$this->db->get('pengangkatanpns')->result_array()); 
   tpl('admin/pengangkatanpns',$x);
  }

  public function pengangkatanpns_tambah()
  {
  $x = array('judul'        => 'Tambah Data Pengangkatan PNS' ,
              'aksi'        => 'tambah',
              'tgl_sk'=> "",
			  'nama'=> "",
			  'no_sk'=> "",
			  'pejabat_ygmenetapkan'=> "",
              'gapok_sk'=> "",
			  'pangkat_sk'=> "",
			  'gol_ruang'=> "",
			  'tmt_pns'=> "",
			  'tahun'=> "",
			  'bulan'=> "",
			  'suket_kesehatan'=> "",
			  'sttpl'=> "",
              'sumpah_janji_pns'=> ""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'tgl_sk'=>$this->input->post('tgl_sk'),
		'nama'=>$this->input->post('nama'),
		'no_sk'=>$this->input->post('no_sk'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'gapok_sk'=>$this->input->post('gapok_sk'),
		'pangkat_sk'=>$this->input->post('pangkat_sk'),
		'gol_ruang'=>$this->input->post('gol_ruang'),
		'tmt_pns'=>$this->input->post('tmt_pns'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'),
		'suket_kesehatan'=>$this->input->post('suket_kesehatan'),
		'sttpl'=>$this->input->post('sttpl'),
		'sumpah_janji_pns'=>$this->input->post('sumpah_janji_pns'));
      $cek=$this->db->insert('pengangkatanpns',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatanpns'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pengangkatanpns_form',$x);
    }
  }
    
  public function pengangkatanpns_edit($id='')
  {
  $sql=$this->db->get_where('pengangkatanpns',array('id_angkat_pns'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Pengangkatan PNS' ,
              'aksi'        =>'tambah',
        'tgl_sk'=>$sql['tgl_sk'],
		'nama'=>$sql['nama'],
		'no_sk'=>$sql['no_sk'],
		'pejabat_ygmenetapkan'=>$sql['pejabat_ygmenetapkan'],
        'gapok_sk'=>$sql['gapok_sk'],
		'pangkat_sk'=>$sql['pangkat_sk'],
		'gol_ruang'=>$sql['gol_ruang'],
		'tmt_pns'=>$sql['tmt_pns'],
		'tahun'=>$sql['tahun'],
		'bulan'=>$sql['bulan'],
		'suket_kesehatan'=>$sql['suket_kesehatan'],
		'sttpl'=>$sql['sttpl'],
        'sumpah_janji_pns'=>$sql['sumpah_janji_pns']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'tgl_sk'=>$this->input->post('tgl_sk'),
		'nama'=>$this->input->post('nama'),
		'no_sk'=>$this->input->post('no_sk'),
		'pejabat_ygmenetapkan'=>$this->input->post('pejabat_ygmenetapkan'),
        'gapok_sk'=>$this->input->post('gapok_sk'),
		'pangkat_sk'=>$this->input->post('pangkat_sk'),
		'gol_ruang'=>$this->input->post('gol_ruang'),
		'tmt_pns'=>$this->input->post('tmt_pns'),
		'tahun'=>$this->input->post('tahun'),
		'bulan'=>$this->input->post('bulan'),
		'suket_kesehatan'=>$this->input->post('suket_kesehatan'),
		'sttpl'=>$this->input->post('sttpl'),
		'sumpah_janji_pns'=>$this->input->post('sumpah_janji_pns'));
      $cek=$this->db->update('pengangkatanpns',$inputData,array('id_angkat_pns'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatanpns'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pengangkatanpns_form',$x);
    }
  }

  
  public function pengangkatanpns_hapus($id='')
  {
   $cek=$this->db->delete('pengangkatanpns',array('id_angkat_pns'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pengangkatanpns'));
   }
  }


 public function kelpeg()
  {
   $x = array('judul' =>':: Data Keluarga Pegawai ::', 
              'data'=>$this->db->get('kelpeg')->result_array()); 
   tpl('admin/kelpeg',$x);
  }

  public function kelpeg_tambah()
  {
  $x = array('judul'        => 'Tambah Data Keluarga Pegawai' ,
              'aksi'        => 'tambah',
              'nip'=>'',
			'nama'=>'',
			'nama_ayah'=>'',
			'tempat_ayah'=>'',
			'tgllahir_ayah'=>'',
			'pekerjaan_ayah'=>'',
			'alamat_ayah'=>'',
			'nama_ibu'=>'',
			'tempat_ibu'=>'',
			'tgllahir_ibu'=>'',
			'pekerjaan_ibu'=>'',
			'alamat_ibu'=>'',
			'nama_is'=>'',
			'jk'=>'',
			'tempat_is'=>'',
			'tgllahir_is'=>'',
			'tglkawin'=>'',
			'pendidikan_akhir_is'=>'',
			'pekerjaan_is'=>'',
			'nip_is'=>'',
			'pangkat_is'=>'',
			'nokk'=>'',
			'nik_is'=>'',
			'opd'=>'',
			'nama_anak1'=>'',
			'tempat_anak1'=>'',
			'tgllahir_anak1'=>'',
			'pekerjaan_anak1'=>'',
			'status_anak1'=>'',
			'pendidikan_anak1'=>'',
			'jk_anak1'=>'',
			'nama_anak2'=>'',
			'tempat_anak2'=>'',
			'tgllahir_anak2'=>'',
			'pekerjaan_anak2'=>'',
			'status_anak2'=>'',
			'pendidikan_anak2'=>'',
			'jk_anak2'=>'',
			'nama_anak3'=>'',
			'tempat_anak3'=>'',
			'tgllahir_anak3'=>'',
			'pekerjaan_anak3'=>'',
			'status_anak3'=>'',
			'pendidikan_anak3'=>'',
			'jk_anak3'=>'',
			'username'=>""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
        'nama'=>$this->input->post('nama'),
        'nama_ayah'=>$this->input->post('nama_ayah'),
		'tempat_ayah'=>$this->input->post('tempat_ayah'),
		'tgllahir_ayah'=>$this->input->post('tgllahir_ayah'),
		'pekerjaan_ayah'=>$this->input->post('pekerjaan_ayah'),
		'alamat_ayah'=>$this->input->post('alamat_ayah'),
		'nama_ibu'=>$this->input->post('nama_ibu'),
		'tempat_ibu'=>$this->input->post('tempat_ibu'),
		'tgllahir_ibu'=>$this->input->post('tgllahir_ibu'),
		'pekerjaan_ibu'=>$this->input->post('pekerjaan_ibu'),
		'alamat_ibu'=>$this->input->post('alamat_ibu'),
		'nama_is'=>$this->input->post('nama_is'),
		'jk'=>$this->input->post('jk'),
		'tempat_is'=>$this->input->post('tempat_is'),
		'tgllahir_is'=>$this->input->post('tgllahir_is'),
		'tglkawin'=>$this->input->post('tglkawin'),
		'pendidikan_akhir_is'=>$this->input->post('pendidikan_akhir_is'),
		'pekerjaan_is'=>$this->input->post('pekerjaan_is'),
		'nip_is'=>$this->input->post('nip_is'),
		'pangkat_is'=>$this->input->post('pangkat_is'),
		'nokk'=>$this->input->post('nokk'),
		'nik_is'=>$this->input->post('nik_is'),
		'opd'=>$this->input->post('opd'),
		'nama_anak1'=>$this->input->post('nama_anak1'),
		'tempat_anak1'=>$this->input->post('tempat_anak1'),
		'tgllahir_anak1'=>$this->input->post('tgllahir_anak1'),
		'pekerjaan_anak1'=>$this->input->post('pekerjaan_anak1'),
		'status_anak1'=>$this->input->post('status_anak1'),
		'pendidikan_anak1'=>$this->input->post('pendidikan_anak1'),
		'jk_anak1'=>$this->input->post('jk_anak1'),
		'nama_anak2'=>$this->input->post('nama_anak2'),
		'tempat_anak2'=>$this->input->post('tempat_anak2'),
		'tgllahir_anak2'=>$this->input->post('tgllahir_anak2'),
		'pekerjaan_anak2'=>$this->input->post('pekerjaan_anak2'),
		'status_anak2'=>$this->input->post('status_anak2'),
		'pendidikan_anak2'=>$this->input->post('pendidikan_anak2'),
		'jk_anak2'=>$this->input->post('jk_anak2'),
		'nama_anak3'=>$this->input->post('nama_anak3'),
		'tempat_anak3'=>$this->input->post('tempat_anak3'),
		'tgllahir_anak3'=>$this->input->post('tgllahir_anak3'),
		'pekerjaan_anak3'=>$this->input->post('pekerjaan_anak3'),
		'status_anak3'=>$this->input->post('status_anak3'),
		'pendidikan_anak3'=>$this->input->post('pendidikan_anak3'),
		'jk_anak3'=>$this->input->post('jk_anak3'),
        'username'=>$this->input->post('username'),
        //'password'=>md5($this->input->post('password'))
        );
      $cek=$this->db->insert('kelpeg',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/kelpeg_form',$x);
    }
  }
    
  public function kelpeg_edit($id='')
  {
  $sql=$this->db->get_where('kelpeg',array('id_kelpeg'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Keluarga Pegawai' ,
              'aksi'        =>'tambah',
    'nip'=>$data['nip'],
	'nama'=>$data['nama'],
    'nama_ayah'=>$data['nama_ayah'],
	'tempat_ayah'=>$data['tempat_ayah'],
	'tgllahir_ayah'=>$data['tgllahir_ayah'],
	'pekerjaan_ayah'=>$data['pekerjaan_ayah'],
	'alamat_ayah'=>$data['alamat_ayah'],
	'nama_ibu'=>$data['nama_ibu'],
	'tempat_ibu'=>$data['tempat_ibu'],
	'tgllahir_ibu'=>$data['tgllahir_ibu'],
	'pekerjaan_ibu'=>$data['pekerjaan_ibu'],
	'alamat_ibu'=>$data['alamat_ibu'],	
	'nama_is'=>$data['nama_is'],
	'jk'=>$data['jk'],
	'tempat_is'=>$data['tempat_is'],
	'tgllahir_is'=>$data['tgllahir_is'],
	'tglkawin'=>$data['tglkawin'],
	'pendidikan_akhir_is'=>$data['pendidikan_akhir_is'],
	'pekerjaan_is'=>$data['pekerjaan_is'],
	'nip_is'=>$data['nip_is'],
	'pangkat_is'=>$data['pangkat_is'],
	'nokk'=>$data['nokk'],
	'nik_is'=>$data['nik_is'],
	'opd'=>$data['opd'],
	'nama_anak1'=>$data['nama_anak1'],
	'tempat_anak1'=>$data['tempat_anak1'],
	'tgllahir_anak1'=>$data['tgllahir_anak1'],
	'pekerjaan_anak1'=>$data['pekerjaan_anak1'],
	'status_anak1'=>$data['status_anak1'],
	'pendidikan_anak1'=>$data['pendidikan_anak1'],
	'jk_anak1'=>$data['jk_anak1'],
	'nama_anak2'=>$data['nama_anak2'],
	'tempat_anak2'=>$data['tempat_anak2'],
	'tgllahir_anak2'=>$data['tgllahir_anak2'],
	'pekerjaan_anak2'=>$data['pekerjaan_anak2'],
	'status_anak2'=>$data['status_anak2'],
	'pendidikan_anak2'=>$data['pendidikan_anak2'],
	'jk_anak2'=>$data['jk_anak2'],
	'nama_anak3'=>$data['nama_anak3'],
	'tempat_anak3'=>$data['tempat_anak3'],
	'tgllahir_anak3'=>$data['tgllahir_anak3'],
	'pekerjaan_anak3'=>$data['pekerjaan_anak3'],
	'status_anak3'=>$data['status_anak3'],
	'pendidikan_anak3'=>$data['pendidikan_anak3'],
	'jk_anak3'=>$data['jk_anak3'],	
    'username'=>$data['username']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
	  'nama'=>$this->input->post('nama'),
      'nama_ayah'=>$this->input->post('nama_ayah'),
	  'tempat_ayah'=>$this->input->post('tempat_ayah'),
	  'tgllahir_ayah'=>$this->input->post('tgllahir_ayah'),
	  'pekerjaan_ayah'=>$this->input->post('pekerjaan_ayah'),
	  'alamat_ayah'=>$this->input->post('alamat_ayah'),
	  'nama_ibu'=>$this->input->post('nama_ibu'),
	  'tempat_ibu'=>$this->input->post('tempat_ibu'),
	  'tgllahir_ibu'=>$this->input->post('tgllahir_ibu'),
	  'pekerjaan_ibu'=>$this->input->post('pekerjaan_ibu'),
	  'alamat_ibu'=>$this->input->post('alamat_ibu'),
	  'nama_is'=>$this->input->post('nama_is'),
	  'jk'=>$this->input->post('jk'),
	  'tempat_is'=>$this->input->post('tempat_is'),
	  'tgllahir_is'=>$this->input->post('tgllahir_is'),
	  'tglkawin'=>$this->input->post('tglkawin'),
	  'pendidikan_akhir_is'=>$this->input->post('pendidikan_akhir_is'),
	  'pekerjaan_is'=>$this->input->post('pekerjaan_is'),
	  'nip_is'=>$this->input->post('nip_is'),
	  'pangkat_is'=>$this->input->post('pangkat_is'),
	  'nokk'=>$this->input->post('nokk'),
	  'nik_is'=>$this->input->post('nik_is'),
	  'opd'=>$this->input->post('opd'),
	  'nama_anak1'=>$this->input->post('nama_anak1'),
	  'tempat_anak1'=>$this->input->post('tempat_anak1'),
	  'tgllahir_anak1'=>$this->input->post('tgllahir_anak1'),
	  'pekerjaan_anak1'=>$this->input->post('pekerjaan_anak1'),
	  'status_anak1'=>$this->input->post('status_anak1'),
	  'pendidikan_anak1'=>$this->input->post('pendidikan_anak1'),
	  'jk_anak1'=>$this->input->post('jk_anak1'),
	  'nama_anak2'=>$this->input->post('nama_anak2'),
	  'tempat_anak2'=>$this->input->post('tempat_anak2'),
	  'tgllahir_anak2'=>$this->input->post('tgllahir_anak2'),
	  'pekerjaan_anak2'=>$this->input->post('pekerjaan_anak2'),
	  'status_anak2'=>$this->input->post('status_anak2'),
	  'pendidikan_anak2'=>$this->input->post('pendidikan_anak2'),
	  'jk_anak2'=>$this->input->post('jk_anak2'),
	  'nama_anak3'=>$this->input->post('nama_anak3'),
	  'tempat_anak3'=>$this->input->post('tempat_anak3'),
	  'tgllahir_anak3'=>$this->input->post('tgllahir_anak3'),
	  'pekerjaan_anak3'=>$this->input->post('pekerjaan_anak3'),
	  'status_anak3'=>$this->input->post('status_anak3'),
	  'pendidikan_anak3'=>$this->input->post('pendidikan_anak3'),
	  'jk_anak3'=>$this->input->post('jk_anak3'),
      'username'=>$this->input->post('username'),
      //'password'=>md5($this->input->post('password'))
      );
      $cek=$this->db->update('kelpeg',$inputData,array('id_kelpeg'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/kelpeg_form',$x);
    }
  }

  
  public function kelpeg_hapus($id='')
  {
   $cek=$this->db->delete('kelpeg',array('id_kelpeg'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg'));
   }
  }


public function menu_riwayat()
  {
      $x = array('judul' =>'Menu Riwayat Pegawai');
      /*$table_to_count = ['pegawai','']
      for ($i=0; $i <=count($table_to_count) ; $i++) { 
        $count_data[i]=$this->m_admin->count_data($table);
      }*/
      tpl('admin/menu_riwayat',$x);
  }






public function pegawai_read()
  {
   $x = array('judul' =>':: Detail Data Pegawai ::', 
              'data'=>$this->db->get('pegawai')->result_array()); 
   tpl('admin/pegawai_read',$x);
  }

  public function pegawai_read_tambah()
  {
  $x = array('judul'        => 'Tambah Detail Data Pegawai' ,
              'aksi'        => 'tambah',
              'nip'=>'',
			'nama'=>'',
			'npwp'=>'',
			'nik'=>'',
			'gelar_kesarjanaan'=>'',
			'tempat'=>'',
			'tgl_lahir'=>'',
			'jk'=>'',
			'foto'=>'',
			'agama'=>'',
			'pendidikan'=>'',
			'status_kep'=>'',
			'alamat'=>'',
			'no_hp'=>'',
			'email'=>'',
			'goldar'=>'',
			'status_kawin'=>'',
			'tgl_pensiun'=>'',
			'no_karpeg'=>'',
			'no_taspen'=>'',
			'username'=>""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
        'nama'=>$this->input->post('nama'),
        'npwp'=>$this->input->post('npwp'),
		'nik'=>$this->input->post('nik'),
		'gelar_kesarjanaan'=>$this->input->post('gelar_kesarjanaan'),
		'tempat'=>$this->input->post('tempat'),
		'tgl_lahir'=>$this->input->post('tgl_lahir'),
		'jk'=>$this->input->post('jk'),
		//'foto'=>$this->upload->file_name,
		'agama'=>$this->input->post('agama'),
		'pendidikan'=>$this->input->post('pendidikan'),
		'status_kep'=>$this->input->post('status_kep'),
		'alamat'=>$this->input->post('alamat'),
		'no_hp'=>$this->input->post('no_hp'),
		'email'=>$this->input->post('email'),
		'goldar'=>$this->input->post('goldar'),
		'status_kawin'=>$this->input->post('status_kawin'),
		'tgl_pensiun'=>$this->input->post('tgl_pensiun'),
		'no_karpeg'=>$this->input->post('no_karpeg'),
		'no_taspen'=>$this->input->post('no_taspen'),
        'username'=>$this->input->post('username'),
        //'password'=>md5($this->input->post('password'))
        );
      $cek=$this->db->insert('pegawai',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pegawai_read'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pegawairead_form',$x);
    }
  }
    
  public function pegawai_read_edit($id='')
  {
  $sql=$this->db->get_where('pegawai',array('id_pegawai'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Detail Data Pegawai' ,
              'aksi'        =>'tambah',
        'nip'=>$data['nip'],
		'nama'=>$data['nama'],
		'npwp'=>$data['npwp'],
		'nik'=>$data['nik'],
		'gelar_kesarjanaan'=>$data['gelar_kesarjanaan'],
		'tempat'=>$data['tempat'],
		'tgl_lahir'=>$data['tgl_lahir'],
		'jk'=>$data['jk'],
		//'foto'=>$this->upload->file_name,
		'agama'=>$data['agama'],
		'pendidikan'=>$data['pendidikan'],
		'status_kep'=>$data['status_kep'],
		'alamat'=>$data['alamat'],
		'no_hp'=>$data['no_hp'],
		'email'=>$data['email'],
		'goldar'=>$data['goldar'],
		'status_kawin'=>$data['status_kawin'],
		'tgl_pensiun'=>$data['tgl_pensiun'],
		'no_karpeg'=>$data['no_karpeg'],
		'no_taspen'=>$data['no_taspen'],
        'username'=>$data['username']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
		'nip'=>$this->input->post('nip'),
        'nama'=>$this->input->post('nama'),
        'npwp'=>$this->input->post('npwp'),
		'nik'=>$this->input->post('nik'),
		'gelar_kesarjanaan'=>$this->input->post('gelar_kesarjanaan'),
		'tempat'=>$this->input->post('tempat'),
		'tgl_lahir'=>$this->input->post('tgl_lahir'),
		'jk'=>$this->input->post('jk'),
		//'foto'=>$this->upload->file_name,
		'agama'=>$this->input->post('agama'),
		'pendidikan'=>$this->input->post('pendidikan'),
		'status_kep'=>$this->input->post('status_kep'),
		'alamat'=>$this->input->post('alamat'),
		'no_hp'=>$this->input->post('no_hp'),
		'email'=>$this->input->post('email'),
		'goldar'=>$this->input->post('goldar'),
		'status_kawin'=>$this->input->post('status_kawin'),
		'tgl_pensiun'=>$this->input->post('tgl_pensiun'),
		'no_karpeg'=>$this->input->post('no_karpeg'),
		'no_taspen'=>$this->input->post('no_taspen'),
        'username'=>$this->input->post('username'),
        //'password'=>md5($this->input->post('password'))
        );
		
      $cek=$this->db->update('pegawai',$inputData,array('id_pegawai'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pegawai_read'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/pegawairead_form',$x);
    }
  }

  
  public function pegawai_read_hapus($id='')
  {
   $cek=$this->db->delete('pegawai',array('id_pegawai'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/pegawai_read'));
   }
  }
  
  
  public function kelpeg2()
  {
   $x = array('judul' =>':: Data Keluarga Pegawai ::', 
              'data'=>$this->db->get('kelpeg')->result_array()); 
   tpl('admin/kelpeg2',$x);
  }

  public function kelpeg2_tambah()
  {
  $x = array('judul'        => 'Tambah Data Keluarga Pegawai' ,
              'aksi'        => 'tambah',
              'nip'=>'',
			'nama_pegawai'=>'',
			'nama_ayah'=>'',
			'tempat_ayah'=>'',
			'tgllahir_ayah'=>'',
			'pekerjaan_ayah'=>'',
			'alamat_ayah'=>'',
			'nama_ibu'=>'',
			'tempat_ibu'=>'',
			'tgllahir_ibu'=>'',
			'pekerjaan_ibu'=>'',
			'alamat_ibu'=>'',
			'nama_is'=>'',
			'jk'=>'',
			'tempat_is'=>'',
			'tgllahir_is'=>'',
			'tglkawin'=>'',
			'pendidikan_akhir_is'=>'',
			'pekerjaan_is'=>'',
			'nip_is'=>'',
			'pangkat_is'=>'',
			'nokk'=>'',
			'nik_is'=>'',
			'opd'=>'',
			'nama_anak1'=>'',
			'tempat_anak1'=>'',
			'tgllahir_anak1'=>'',
			'pekerjaan_anak1'=>'',
			'status_anak1'=>'',
			'pendidikan_anak1'=>'',
			'jk_anak1'=>'',
			'nama_anak2'=>'',
			'tempat_anak2'=>'',
			'tgllahir_anak2'=>'',
			'pekerjaan_anak2'=>'',
			'status_anak2'=>'',
			'pendidikan_anak2'=>'',
			'jk_anak2'=>'',
			'nama_anak3'=>'',
			'tempat_anak3'=>'',
			'tgllahir_anak3'=>'',
			'pekerjaan_anak3'=>'',
			'status_anak3'=>'',
			'pendidikan_anak3'=>'',
			'jk_anak3'=>'',
			'username'=>""); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
        'nama_pegawai'=>$this->input->post('nama_pegawai'),
        'nama_ayah'=>$this->input->post('nama_ayah'),
		'tempat_ayah'=>$this->input->post('tempat_ayah'),
		'tgllahir_ayah'=>$this->input->post('tgllahir_ayah'),
		'pekerjaan_ayah'=>$this->input->post('pekerjaan_ayah'),
		'alamat_ayah'=>$this->input->post('alamat_ayah'),
		'nama_ibu'=>$this->input->post('nama_ibu'),
		'tempat_ibu'=>$this->input->post('tempat_ibu'),
		'tgllahir_ibu'=>$this->input->post('tgllahir_ibu'),
		'pekerjaan_ibu'=>$this->input->post('pekerjaan_ibu'),
		'alamat_ibu'=>$this->input->post('alamat_ibu'),
		'nama_is'=>$this->input->post('nama_is'),
		'jk'=>$this->input->post('jk'),
		'tempat_is'=>$this->input->post('tempat_is'),
		'tgllahir_is'=>$this->input->post('tgllahir_is'),
		'tglkawin'=>$this->input->post('tglkawin'),
		'pendidikan_akhir_is'=>$this->input->post('pendidikan_akhir_is'),
		'pekerjaan_is'=>$this->input->post('pekerjaan_is'),
		'nip_is'=>$this->input->post('nip_is'),
		'pangkat_is'=>$this->input->post('pangkat_is'),
		'nokk'=>$this->input->post('nokk'),
		'nik_is'=>$this->input->post('nik_is'),
		'opd'=>$this->input->post('opd'),
		'nama_anak1'=>$this->input->post('nama_anak1'),
		'tempat_anak1'=>$this->input->post('tempat_anak1'),
		'tgllahir_anak1'=>$this->input->post('tgllahir_anak1'),
		'pekerjaan_anak1'=>$this->input->post('pekerjaan_anak1'),
		'status_anak1'=>$this->input->post('status_anak1'),
		'pendidikan_anak1'=>$this->input->post('pendidikan_anak1'),
		'jk_anak1'=>$this->input->post('jk_anak1'),
		'nama_anak2'=>$this->input->post('nama_anak2'),
		'tempat_anak2'=>$this->input->post('tempat_anak2'),
		'tgllahir_anak2'=>$this->input->post('tgllahir_anak2'),
		'pekerjaan_anak2'=>$this->input->post('pekerjaan_anak2'),
		'status_anak2'=>$this->input->post('status_anak2'),
		'pendidikan_anak2'=>$this->input->post('pendidikan_anak2'),
		'jk_anak2'=>$this->input->post('jk_anak2'),
		'nama_anak3'=>$this->input->post('nama_anak3'),
		'tempat_anak3'=>$this->input->post('tempat_anak3'),
		'tgllahir_anak3'=>$this->input->post('tgllahir_anak3'),
		'pekerjaan_anak3'=>$this->input->post('pekerjaan_anak3'),
		'status_anak3'=>$this->input->post('status_anak3'),
		'pendidikan_anak3'=>$this->input->post('pendidikan_anak3'),
		'jk_anak3'=>$this->input->post('jk_anak3'),
        'username'=>$this->input->post('username'),
        //'password'=>md5($this->input->post('password'))
        );
      $cek=$this->db->insert('kelpeg',$inputData);
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Ditambahkan.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg2'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/kelpeg2_form',$x);
    }
  }
    
  public function kelpeg2_edit($id='')
  {
  $sql=$this->db->get_where('kelpeg',array('id_kelpeg'=>$id))->row_array(); 
  $x = array('judul'        =>'Tambah Data Keluarga Pegawai' ,
              'aksi'        =>'tambah',
    'nip'=>$data['nip'],
	'nama_pegawai'=>$data['nama_pegawai'],
    'nama_ayah'=>$data['nama_ayah'],
	'tempat_ayah'=>$data['tempat_ayah'],
	'tgllahir_ayah'=>$data['tgllahir_ayah'],
	'pekerjaan_ayah'=>$data['pekerjaan_ayah'],
	'alamat_ayah'=>$data['alamat_ayah'],
	'nama_ibu'=>$data['nama_ibu'],
	'tempat_ibu'=>$data['tempat_ibu'],
	'tgllahir_ibu'=>$data['tgllahir_ibu'],
	'pekerjaan_ibu'=>$data['pekerjaan_ibu'],
	'alamat_ibu'=>$data['alamat_ibu'],	
	'nama_is'=>$data['nama_is'],
	'jk'=>$data['jk'],
	'tempat_is'=>$data['tempat_is'],
	'tgllahir_is'=>$data['tgllahir_is'],
	'tglkawin'=>$data['tglkawin'],
	'pendidikan_akhir_is'=>$data['pendidikan_akhir_is'],
	'pekerjaan_is'=>$data['pekerjaan_is'],
	'nip_is'=>$data['nip_is'],
	'pangkat_is'=>$data['pangkat_is'],
	'nokk'=>$data['nokk'],
	'nik_is'=>$data['nik_is'],
	'opd'=>$data['opd'],
	'nama_anak1'=>$data['nama_anak1'],
	'tempat_anak1'=>$data['tempat_anak1'],
	'tgllahir_anak1'=>$data['tgllahir_anak1'],
	'pekerjaan_anak1'=>$data['pekerjaan_anak1'],
	'status_anak1'=>$data['status_anak1'],
	'pendidikan_anak1'=>$data['pendidikan_anak1'],
	'jk_anak1'=>$data['jk_anak1'],
	'nama_anak2'=>$data['nama_anak2'],
	'tempat_anak2'=>$data['tempat_anak2'],
	'tgllahir_anak2'=>$data['tgllahir_anak2'],
	'pekerjaan_anak2'=>$data['pekerjaan_anak2'],
	'status_anak2'=>$data['status_anak2'],
	'pendidikan_anak2'=>$data['pendidikan_anak2'],
	'jk_anak2'=>$data['jk_anak2'],
	'nama_anak3'=>$data['nama_anak3'],
	'tempat_anak3'=>$data['tempat_anak3'],
	'tgllahir_anak3'=>$data['tgllahir_anak3'],
	'pekerjaan_anak3'=>$data['pekerjaan_anak3'],
	'status_anak3'=>$data['status_anak3'],
	'pendidikan_anak3'=>$data['pendidikan_anak3'],
	'jk_anak3'=>$data['jk_anak3'],	
    'username'=>$data['username']); 
    if(isset($_POST['kirim'])){
      $inputData=array(
        'nip'=>$this->input->post('nip'),
	  'nama_pegawai'=>$this->input->post('nama_pegawai'),
      'nama_ayah'=>$this->input->post('nama_ayah'),
	  'tempat_ayah'=>$this->input->post('tempat_ayah'),
	  'tgllahir_ayah'=>$this->input->post('tgllahir_ayah'),
	  'pekerjaan_ayah'=>$this->input->post('pekerjaan_ayah'),
	  'alamat_ayah'=>$this->input->post('alamat_ayah'),
	  'nama_ibu'=>$this->input->post('nama_ibu'),
	  'tempat_ibu'=>$this->input->post('tempat_ibu'),
	  'tgllahir_ibu'=>$this->input->post('tgllahir_ibu'),
	  'pekerjaan_ibu'=>$this->input->post('pekerjaan_ibu'),
	  'alamat_ibu'=>$this->input->post('alamat_ibu'),
	  'nama_is'=>$this->input->post('nama_is'),
	  'jk'=>$this->input->post('jk'),
	  'tempat_is'=>$this->input->post('tempat_is'),
	  'tgllahir_is'=>$this->input->post('tgllahir_is'),
	  'tglkawin'=>$this->input->post('tglkawin'),
	  'pendidikan_akhir_is'=>$this->input->post('pendidikan_akhir_is'),
	  'pekerjaan_is'=>$this->input->post('pekerjaan_is'),
	  'nip_is'=>$this->input->post('nip_is'),
	  'pangkat_is'=>$this->input->post('pangkat_is'),
	  'nokk'=>$this->input->post('nokk'),
	  'nik_is'=>$this->input->post('nik_is'),
	  'opd'=>$this->input->post('opd'),
	  'nama_anak1'=>$this->input->post('nama_anak1'),
	  'tempat_anak1'=>$this->input->post('tempat_anak1'),
	  'tgllahir_anak1'=>$this->input->post('tgllahir_anak1'),
	  'pekerjaan_anak1'=>$this->input->post('pekerjaan_anak1'),
	  'status_anak1'=>$this->input->post('status_anak1'),
	  'pendidikan_anak1'=>$this->input->post('pendidikan_anak1'),
	  'jk_anak1'=>$this->input->post('jk_anak1'),
	  'nama_anak2'=>$this->input->post('nama_anak2'),
	  'tempat_anak2'=>$this->input->post('tempat_anak2'),
	  'tgllahir_anak2'=>$this->input->post('tgllahir_anak2'),
	  'pekerjaan_anak2'=>$this->input->post('pekerjaan_anak2'),
	  'status_anak2'=>$this->input->post('status_anak2'),
	  'pendidikan_anak2'=>$this->input->post('pendidikan_anak2'),
	  'jk_anak2'=>$this->input->post('jk_anak2'),
	  'nama_anak3'=>$this->input->post('nama_anak3'),
	  'tempat_anak3'=>$this->input->post('tempat_anak3'),
	  'tgllahir_anak3'=>$this->input->post('tgllahir_anak3'),
	  'pekerjaan_anak3'=>$this->input->post('pekerjaan_anak3'),
	  'status_anak3'=>$this->input->post('status_anak3'),
	  'pendidikan_anak3'=>$this->input->post('pendidikan_anak3'),
	  'jk_anak3'=>$this->input->post('jk_anak3'),
      'username'=>$this->input->post('username'),
      //'password'=>md5($this->input->post('password'))
      );
      $cek=$this->db->update('kelpeg',$inputData,array('id_kelpeg'=>$id));
      if($cek){
        $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Diedit.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg2'));
      }else{
       echo "ERROR input Data";
      }
    }else{
     tpl('admin/kelpeg2_form',$x);
    }
  }

  
  public function kelpeg2_hapus($id='')
  {
   $cek=$this->db->delete('kelpeg',array('id_kelpeg'=>$id));
   if ($cek) {
    $pesan='<div class="alert alert-success alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <h4><i class="icon fa fa-check"></i> Success!</h4>
               Data Berhasil Di Hapus.
              </div>';
    $this->session->set_flashdata('pesan',$pesan);
    redirect(base_url('admin/kelpeg2'));
   }
  }

public function excel()
  {
	  var_dump("tes");die();
      $data['pegawai'] = $this->m_pegawai->tampil_data('pegawai')->result();
	  
	  require(APPPATH. 'PHPExcel-1.8/Classes/PHPExcel.php');
	  require(APPPATH. 'PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');
	  
	  $object = new PHPExcel();
	  
	  $object->getProperties()->setCreator("Aulia Dinin");
	  $object->getProperties()->setLastModifiedBy("Aulia");
	  $object->getProperties()->setTitle("Daftar Pegawai");
	  
	  $object->setActiveSheetIndex(0);
      $object->getActiveSheet()->setCellValue('A1', 'No');
      $object->getActiveSheet()->setCellValue('B1', 'Nip');
      $object->getActiveSheet()->setCellValue('C1', 'Npwp');
      $object->getActiveSheet()->setCellValue('D1', 'Nik');
	  $object->getActiveSheet()->setCellValue('E1', 'Gelar Kesarjanaan');
      $object->getActiveSheet()->setCellValue('F1', 'Tempat');
      $object->getActiveSheet()->setCellValue('G1', 'Tanggal Lahir');
	  $object->getActiveSheet()->setCellValue('H1', 'Nama');
      $object->getActiveSheet()->setCellValue('I1', 'Jenis Kelamin');
      $object->getActiveSheet()->setCellValue('J1', 'Agama');
	  $object->getActiveSheet()->setCellValue('K1', 'Pendidikan');
	  $object->getActiveSheet()->setCellValue('L1', 'Status Kepegawaian');
	  $object->getActiveSheet()->setCellValue('M1', 'Alamat');
	  $object->getActiveSheet()->setCellValue('N1', 'No HP');
	  $object->getActiveSheet()->setCellValue('O1', 'Email');
	  $object->getActiveSheet()->setCellValue('P1', 'Status Kawin');
	  $object->getActiveSheet()->setCellValue('Q1', 'Tanggal Pensiun');
	  $object->getActiveSheet()->setCellValue('R1', 'No Karpeg');
      $object->getActiveSheet()->setCellValue('S1', 'No Taspen');
	  
	  $baris = 2;
	  $no = 1;
	  
	  foreach ($data['pegawai'] as $peg){
		  $object->getActiveSheet()->setCellValue('A1'.$baris, $no++);
		  $object->getActiveSheet()->setCellValue('B1'.$baris, $peg->nip);
		  $object->getActiveSheet()->setCellValue('C1'.$baris, $peg->npwp);
		  $object->getActiveSheet()->setCellValue('D1'.$baris, $peg->nik);
		  $object->getActiveSheet()->setCellValue('E1'.$baris, $peg->gelar_kesarjanaan);
		  $object->getActiveSheet()->setCellValue('F1'.$baris, $peg->tempat);
		  $object->getActiveSheet()->setCellValue('G1'.$baris, $peg->tgl_lahir);
		  $object->getActiveSheet()->setCellValue('H1'.$baris, $peg->nama);
		  $object->getActiveSheet()->setCellValue('I1'.$baris, $peg->jk);
		  $object->getActiveSheet()->setCellValue('J1'.$baris, $peg->agama);
		  $object->getActiveSheet()->setCellValue('K1'.$baris, $peg->pendidikan);
		  $object->getActiveSheet()->setCellValue('L1'.$baris, $peg->status_kep);
		  $object->getActiveSheet()->setCellValue('M1'.$baris, $peg->alamat);
		  $object->getActiveSheet()->setCellValue('N1'.$baris, $peg->no_hp);
		  $object->getActiveSheet()->setCellValue('O1'.$baris, $peg->email);
		  $object->getActiveSheet()->setCellValue('P1'.$baris, $peg->status_kawin);
		  $object->getActiveSheet()->setCellValue('Q1'.$baris, $peg->tgl_pensiun);
		  $object->getActiveSheet()->setCellValue('R1'.$baris, $peg->no_karpeg);
		  $object->getActiveSheet()->setCellValue('S1'.$baris, $peg->no_taspen);
		  
		  $baris++;
	  }
	  $filename="Data_Pegawai".'.xlsx';
	  
	  $object->getActiveSheet()->setTitle("Data Pegawai");
	  
	  header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
	  header('Content-Disposition: attachment;filename="'.$filename.'"');
	  header('Cache-Control: max-age=0');
	  
	  $writer=PHPExcel_IOFactory::createwriter($object, 'Excel2007');
	  $writer->save('php://output');
	  
  }




public function keluar($value='')
{

$this->session->sess_destroy();
echo "<scrip>alert('Anda Telah Keluar Dari Halaman Administrator')</script>";;
redirect(base_url(''));
}
  
}