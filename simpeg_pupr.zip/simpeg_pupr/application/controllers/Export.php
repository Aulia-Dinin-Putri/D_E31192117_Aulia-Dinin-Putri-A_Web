<?php defined('BASEPATH') OR die('No direct script access allowed');

require('./excel/vendor/autoload.php');

use PhpOffice\PhpSpreadsheet\Helper\Sample;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class Export extends CI_Controller {

     public function __construct()
     {
          parent::__construct();
         $this->load->model('export_model');
     }

     public function index()
     {
          $data['peg'] = $this->export_model->getAll()->result();
          $this->load->view('export', $data);
     }

     public function export()
     {
          $peg = $this->export_model->getAll()->result();

          $spreadsheet = new Spreadsheet;

          $spreadsheet->setActiveSheetIndex(0)
                      ->setCellValue('A1', 'No')
                      ->setCellValue('B1', 'Nip')
                      ->setCellValue('C1', 'Npwp')
                      ->setCellValue('D1', 'Nik')
					  ->setCellValue('E1', 'Gelar Kesarjanaan')
                      ->setCellValue('F1', 'Tempat')
                      ->setCellValue('G1', 'Tanggal Lahir')
					  ->setCellValue('H1', 'Nama')
                      ->setCellValue('I1', 'Jenis Kelamin')
                      ->setCellValue('J1', 'Agama')
					  ->setCellValue('K1', 'Pendidikan')
					  ->setCellValue('L1', 'Status Kepegawaian')
					  ->setCellValue('M1', 'Alamat')
					  ->setCellValue('N1', 'No HP')
					  ->setCellValue('O1', 'Email')
					  ->setCellValue('P1', 'Status Kawin')
					  ->setCellValue('Q1', 'Tanggal Pensiun')
					  ->setCellValue('R1', 'No Karpeg')
                      ->setCellValue('S1', 'No Taspen');

          $kolom = 2;
          $nomor = 1;
          foreach($peg as $pegawai) {

               $spreadsheet->setActiveSheetIndex(0)
                           ->setCellValue('A' . $kolom, $nomor)
                           ->setCellValue('B' . $kolom, $pegawai->nip)
                           ->setCellValue('C' . $kolom, $pegawai->npwp)
						   ->setCellValue('D' . $kolom, $pegawai->nik)
                           ->setCellValue('E' . $kolom, $pegawai->gelar_kesarjanaan)
                           ->setCellValue('F' . $kolom, $pegawai->tempat)
						   ->setCellValue('G' . $kolom, date('j F Y', strtotime($pegawai->tgl_lahir)))
                           ->setCellValue('H' . $kolom, $pegawai->nama)
                           ->setCellValue('I' . $kolom, $pegawai->jk)
						   ->setCellValue('J' . $kolom, $pegawai->agama)
                           ->setCellValue('K' . $kolom, $pegawai->pendidikan)
                           ->setCellValue('L' . $kolom, $pegawai->status_kep)
						   ->setCellValue('M' . $kolom, $pegawai->alamat)
						   ->setCellValue('N' . $kolom, $pegawai->no_hp)
                           ->setCellValue('O' . $kolom, $pegawai->email)
                           ->setCellValue('P' . $kolom, $pegawai->status_kawin)
						   ->setCellValue('Q' . $kolom, date('j F Y', strtotime($pegawai->tgl_pensiun)))
						   ->setCellValue('R' . $kolom, $pegawai->no_karpeg)
						   ->setCellValue('S' . $kolom, $pegawai->no_taspen);

               $kolom++;
               $nomor++;

          }

          $writer = new Xlsx($spreadsheet);

          header('Content-Type: application/vnd.ms-excel');
	  header('Content-Disposition: attachment;filename="Latihan.xlsx"');
	  header('Cache-Control: max-age=0');

	  $writer->save('php://output');
     }
}