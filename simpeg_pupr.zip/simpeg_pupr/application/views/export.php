<!DOCTYPE html>
<html>
<head>
     <title>Export To Excel</title>
</head>
<body>
     <a href="<?php echo base_url('excel'); ?>">Export Data</a>
     <table border="1" cellspacing="0">
          <thead>
               <tr>
                    <th style="width: 7%; text-align: center;">No</th>
                    <th style="width: 30%">Nama</th>
					<th>Nip</th>
					<th>Npwp</th>
					<th>Nik</th>
					<th>Gelar Kesarjanaan</th>
					<th>Tempat</th>
					<th>Tanggal Lahir</th>
					<th>Jenis Kelamin</th>
					<th>Agama</th>
					<th>Pendidikan</th>
					<th>Status Kepegawaian</th>
					<th>Alamat</th>
					<th style="text-align: center;">No HP</th>
					<th>Email</th>
					<th>Status Kawin</th>
					<th>Tanggal Pensiun</th>
					<th>No Karpeg</th>
					<th>No Taspen</th>
               </tr>
          </thead>
          <tbody>
               <?php $index = 1; ?>
               <?php foreach($peg as $pegawai): ?>
                    <tr>
                         <td style="width: 7%; text-align: center;"><?php echo $index++; ?></td>
                         <td style="width: 30%"><?php echo $pegawai->nama; ?></td>
                         <td><?php echo $pegawai->nip; ?></td>
						 <td><?php echo $pegawai->npwp; ?></td>
						 <td><?php echo $pegawai->nik; ?></td>
						 <td><?php echo $pegawai->gelar_kesarjanaan; ?></td>
						 <td><?php echo $pegawai->tempat; ?></td>
                         <td><?php echo date('j F Y', strtotime($pegawai->tgl_lahir)); ?></td>
						 <td><?php echo $pegawai->jk; ?></td>
						 <td><?php echo $pegawai->agama; ?></td>
						 <td><?php echo $pegawai->pendidikan; ?></td>
						 <td><?php echo $pegawai->status_kep; ?></td>
						 <td><?php echo $pegawai->alamat; ?></td>
                         <td style="text-align: center;"><?php echo $pegawai->no_hp; ?></td>
						 <td><?php echo $pegawai->email; ?></td>
						 <td><?php echo $pegawai->status_kawin; ?></td>
						 <td><?php echo date('j F Y', strtotime($pegawai->tgl_pensiun)); ?></td>
						 <td><?php echo $pegawai->no_karpeg; ?></td>
						 <td><?php echo $pegawai->no_taspen; ?></td>
                    </tr>
               <?php endforeach; ?>
          </tbody>
     </table>
</body>
</html>