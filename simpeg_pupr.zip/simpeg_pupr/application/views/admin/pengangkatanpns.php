<td><a href="<?= base_url('admin/pengangkatanpns_tambah/') ?>" class="btn btn-primary">Tambah</a><a href="pengangkatanpns"> <button onClick="window.print();" class="btn btn-warning" >Print Data</button></a> </td>
<br /><br /><br />
<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
				  <!--<th>Tanggal</th>-->
                  <th>Nama Pegawai</th>
				  <!--<th>Nomor Surat Keputusan</th>
                  <th>Pejabat yang menetapkan</th>
                  <th>Gapok Surat Keputusan</th>-->
				  <th>Pangkat</th>
				  <th>Golongan Ruang</th>
				  <th>T.M.T PNS</th>
				  <!--<th>Tahun</th>
				  <th>Bulan</th>
				  <th>Suket Kesehatan</th>
				  <th>STTPL</th>
				  <th>Sumpah/Janji/PNS</th>-->
                  <th>Aksi</th>
                </tr>
                </thead>
                 <tbody>
                 <?php $no=1; foreach($data as $admin): ?>
                 <tr>
                 <td><?= $no ?></td>
				 <!--<td><?= $admin['tgl_sk'] ?></td>-->
				 <td><?= $admin['nama'] ?></td>
                 <!--<td><?= $admin['no_sk'] ?></td> 
                 <td><?= $admin['pejabat_ygmenetapkan'] ?></td>
				 <td><?= $admin['gapok_sk'] ?></td>-->
				 <td><?= $admin['pangkat_sk'] ?></td>
				 <td><?= $admin['gol_ruang'] ?></td>
				 <td><?= $admin['tmt_pns'] ?></td>
				 <!--<td><?= $admin['tahun'] ?></td>
				 <td><?= $admin['bulan'] ?></td>
				 <td><?= $admin['suket_kesehatan'] ?></td>
				 <td><?= $admin['sttpl'] ?></td>
				 <td><?= $admin['sumpah_janji_pns'] ?></td>-->
                 <td><a href="<?= base_url('admin/pengangkatanpns_edit/'.$admin['id_angkat_pns']) ?>" class="btn btn-info">Edit</a> <a href="<?= base_url('admin/pengangkatanpns_hapus/'.$admin['id_angkat_pns']) ?>" class="btn btn-danger">Hapus</a></td> 
                 </tr>

                 <?php $no++; endforeach; ?>
                 
                 </tbody>
              </table>


 
 
 