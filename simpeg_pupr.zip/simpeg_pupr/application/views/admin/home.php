<?php
 if($this->session->userdata('level') == "admin" ){

 ?>
<!--<h1 class="h4 text-black-900 mb-4"><center><font size="5" face="Sunday Best">HOME</font></center></h1>-->
<br /><br />

<html>
<div id="chart_div"></div>
<br><br>
<a href=https://www.plus2net.com/php_tutorial/chart-database.php>hall</a>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
 google.charts.load('current', {'packages':['corechart']});
     // Draw the pie chart when Charts is loaded.
      google.charts.setOnLoadCallback(draw_my_chart);
      // Callback that draws the pie chart
      function draw_my_chart() {
        // Create the data table .
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'language');
        data.addColumn('number', 'Nos');
for(i=0;i<my_2d.length;i++)
data.addRow([my_2d[i][0],parseInt(my_2d[i][1])]);

// above row adds the JavaScript two dimensional array data into required chart format
    var options = {title:'plus2net.com :Nos of tutorials',
           width:500,
           height:500,
		   legend:'left',
           is3D:true,
		   };

        // Instantiate and draw the chart
        var chart = new google.visualization.PieChart(document.getElementById('chart_div'));
        chart.draw(data, options);
      }
</script>
</html>
<br><br>

<html>
<div class="col-lg-6 col-xs-12">
<!-- <head><h3>Perbandingan Jumlah Pegawai</h3></head> -->
<script type="text/javascript" src="Chart.js"></script>
<section class="content">
        <div class="row">
            <!-- DONUT CHART -->
            <div class="box box-header">
              <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-pie-chart"></i>&nbsp;&nbsp;Grafik Perbandingan Jumlah Pegawai</h3>

                <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                </div>
              </div>
              <div class="box-body">
                <canvas id="pieChart" style="height:250px"></canvas>
				<script>
				var ctx = document.getElementById("myChart").getContext('2d');
				var myChart = new Chart(ctx, {
					type: 'pie',
					data:{
						labels: <?php echo json_encode($peg['nama']); ?>,
						datasets:[{
							label: 'Grafik Perbandingan Jumlah Pegawai',
							data: <?php echo json_encode($jk); ?>,
							backgroundColor: 'rgba(255, 99, 132, 0.2)',
							borderColor: 'rgba(255,99,132,1)',
							borderWidth: 1
							}]
							},
							options:{
								scales: {
									yAxes: [{
										ticks: {
											beginAtZero:true
										}
									}]
								}
							}
				});
              </script>
			  </div>
			</div>
		</div></section>
</div>
</html>

<html>
<div class="col-lg-6 col-xs-12">
<!--  <head><h3>Pegawai Dengan Penghargaan Terbanyak</h3></head> -->
<script type="text/javascript" src="Chart.js"></script>
<section class="content">
        <div class="row">
            <!-- DONUT CHART -->
            <div class="box box-header">
              <div class="box-header with-border">
                <h3 class="box-title"><i class="fa fa-pie-chart"></i>&nbsp;&nbsp;Grafik Pegawai Dengan Penghargaan Terbanyak</h3>

                <div class="box-tools pull-right">
                  <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                </div>
              </div>
              <div class="box-body">
                <canvas id="pieChart" style="height:250px"></canvas>
				<script>
				var ctx = document.getElementById("myChart").getContext('2d');
				var myChart = new Chart(ctx, {
					type: 'pie',
					data:{
						labels: <?php echo json_encode($peg['nama']); ?>,
						datasets:[{
							label: 'Grafik Perbandingan Jumlah Pegawai',
							data: <?php echo json_encode($jk); ?>,
							backgroundColor: 'rgba(255, 99, 132, 0.2)',
							borderColor: 'rgba(255,99,132,1)',
							borderWidth: 1
							}]
							},
							options:{
								scales: {
									yAxes: [{
										ticks: {
											beginAtZero:true
										}
									}]
								}
							}
				});
              </script>
              </div>
			 </div>
			 </div></section>
</div>
</html>

<br><br>
<body>
<script>
    $(function() {
      /* ChartJS
       * -------
       * Here we will create a few charts using ChartJS
       */




      /* <?php// $color1 = '#f56954'; $color2 = '#f39c12'; $color3 = '#00c0ef'; $color4 = '#3c8dbc'; $color5 = '#000080'; ?>
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieChart       = new Chart(pieChartCanvas)
      var PieData        = [
        <?php// foreach ($data7 as $dt) { ?>
        {
          value    : <?php// echo $dt['jumlah']; ?>,
          color    : <?php// echo $color.$x; ?>,
          highlight: '#d2d6de',
          label    : <?php// echo $dt['tingkat']; ?>
        }, <?php// $x++;} ?>
      ] */
      var color1 = '#f56954'
      var color2 = '#f39c12'
      var color3 = '#00c0ef'
      var color4 = '#3c8dbc'
      var color5 = '#000080'
      //-------------
      //- PIE CHART -
      //-------------
      // Get context with jQuery - using jQuery's .get() method.
      var pieChartCanvas = $('#pieChart').get(0).getContext('2d')
      var pieChart = new Chart(pieChartCanvas)
      var PieData = [
        <?php $x = 1;
        foreach ($data5 as $dt) { ?> {
            value: <?php echo $dt['jumlah']; ?>,
            color: color<?php echo $x; ?>,
            highlight: '#d2d6de',
            label: '<?php echo $dt['namaProdi'] ?>'
          },
        <?php $x++;
        } ?>
      ]
      var pieOptions = {
        //Boolean - Whether we should show a stroke on each segment
        segmentShowStroke: true,
        //String - The colour of each segment stroke
        segmentStrokeColor: '#fff',
        //Number - The width of each segment stroke
        segmentStrokeWidth: 2,
        //Number - The percentage of the chart that we cut out of the middle
        percentageInnerCutout: 50, // This is 0 for Pie charts
        //Number - Amount of animation steps
        animationSteps: 100,
        //String - Animation easing effect
        animationEasing: 'easeOutBounce',
        //Boolean - Whether we animate the rotation of the Doughnut
        animateRotate: true,
        //Boolean - Whether we animate scaling the Doughnut from the centre
        animateScale: false,
        //Boolean - whether to make the chart responsive to window resizing
        responsive: true,
        // Boolean - whether to maintain the starting aspect ratio or not when responsive, if set to false, will take up entire container
        maintainAspectRatio: true,
        //String - A legend template
        legendTemplate: '<ul class="<%=name.toLowerCase()%>-legend"><% for (var i=0; i<segments.length; i++){%><li><span style="background-color:<%=segments[i].fillColor%>"></span><%if(segments[i].label){%><%=segments[i].label%><%}%></li><%}%></ul>'
      }
      //Create pie or douhnut chart
      // You can switch between pie and douhnut using the method below.
      pieChart.Doughnut(PieData, pieOptions)
    })
  </script>
  <script>
    $(function() {
      //Initialize Select2 Elements
      $('.select2').select2()

      //Datemask dd/mm/yyyy
      $('#datemask').inputmask('dd/mm/yyyy', {
        'placeholder': 'dd/mm/yyyy'
      })
      //Datemask2 mm/dd/yyyy
      $('#datemask2').inputmask('mm/dd/yyyy', {
        'placeholder': 'mm/dd/yyyy'
      })
      //Money Euro
      $('[data-mask]').inputmask()

      //Date range picker
      $('#reservation').daterangepicker()
      //Date range picker with time picker
      $('#reservationtime').daterangepicker({
        timePicker: true,
        timePickerIncrement: 30,
        format: 'MM/DD/YYYY h:mm A'
      })
      //Date range as a button
      $('#daterange-btn').daterangepicker({
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function(start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'))
        }
      )

      //Date picker
      $('#datepicker').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true
      })

      //iCheck for checkbox and radio inputs
      $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
        checkboxClass: 'icheckbox_minimal-blue',
        radioClass: 'iradio_minimal-blue'
      })
      //Red color scheme for iCheck
      $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
        checkboxClass: 'icheckbox_minimal-red',
        radioClass: 'iradio_minimal-red'
      })
      //Flat red color scheme for iCheck
      $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
        checkboxClass: 'icheckbox_flat-green',
        radioClass: 'iradio_flat-green'
      })

      //Colorpicker
      $('.my-colorpicker1').colorpicker()
      //color picker with addon
      $('.my-colorpicker2').colorpicker()

      //Timepicker
      $('.timepicker').timepicker({
        showInputs: false
      })
    })
  </script>
</body>
</body>
<br><br>

<div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3></h3>

              <p>Identitas Pegawai</p>
            </div>
            <div class="icon">
              <i class="fa fa-user"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/pegawai" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3></h3>

              <p>Data Penggajian Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-address-card"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/gaji" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3></h3>

              <p>Identitas Keluarga Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-users"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/kelpeg" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3></h3>

              <p>Pengangkatan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-cubes"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/menu_pengangkatan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

        <div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-purple">
            <div class="inner">
              <h3></h3>

              <p>Tunjangan Pendapatan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-money"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/tpp" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>


        <div class="col-lg-6 col-xs-12">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3></h3>
              
              <p>Penghargaan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-database"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/penghargaan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
		<div class="col-lg-12 col-xs-24">
          <!-- small box -->
          <div class="small-box bg-aqua">
            <div class="inner">
              <h3></h3>

              <p>Data Riwayat Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-database"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/menu_riwayat" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

              <div class="chart">
                <canvas id="barChart" style="height:230px"></canvas>
              </div>
<?php } ?>