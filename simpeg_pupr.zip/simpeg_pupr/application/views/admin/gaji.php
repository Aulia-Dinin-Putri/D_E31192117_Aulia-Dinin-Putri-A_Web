<a href="<?= base_url('admin/gaji_tambah/') ?>" class="btn btn-primary">Set Gaji</a>
<br /><br /><br />
<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nip</th>
                  <th>Nama Pegawai</th>
				  <th>Pejabat yang menetapkan</th>
				  <th>Nomor</th>
                  <th>Jenis Kelamin</th>
                  <th>Foto</th>
                  <th>Status Kepegawaian</th>
                  <th>Jumlah Gaji</th>
				  <th>Tanggal Penggajian</th>
				  <th>Gaji Pokok</th>
				  <th>T.M.T KGB</th>
				  <th>Tahun</th>
				  <th>Bulan</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                 <tbody>
                 <?php $no=1; foreach($data->result_array() as $admin): ?>
                 <tr>
                 <td><?= $no ?></td>
                 <td><?= $admin['nip'] ?></td> 
                 <td><?= $admin['nama'] ?></td>
				 <td><?= $admin['pejabat_ygmenetapkan'] ?></td>
				 <td><?= $admin['nomor'] ?></td>
                 <td><?php if($admin['jk'] == "L"){ echo "Laki-Laki";}else{ echo "Perempuan";} ?></td>
                 <td><img src="<?= base_url('template/data/'.$admin['foto']) ?>" class="img-responsive" style="width: 100px;height: 100xp"></td>
                 <td><?= $admin['status_kep'] ?></td>
                 <td>Rp .<?= number_format($admin['jumlah']) ?></td>
                 <td><?= $admin['tgl_gaji'] ?></td>
				 <td>Rp .<?= number_format($admin['gaji_pokok']) ?></td>
				 <td><?= $admin['tmt_kgb'] ?></td>
				 <td><?= $admin['tahun'] ?></td>
                 <td><?= $admin['bulan'] ?></td>
                 <td><a href="<?= base_url('admin/gaji_hapus/'.$admin['id_gaji']) ?>" onclick="return(confirm('Anda Yakin ?'))" class="btn btn-danger">Hapus</a></td> 
                 </tr>
                 <?php $no++; endforeach; ?>
                 </tbody>
               </table>

 
 