<?php if($print == TRUE):
$nilai="
<script>window.print()</script>
<link rel=\"stylesheet\" href=\"".base_url('/template/admin/bower_components/bootstrap/dist/css/bootstrap.min.css')."\">
<h2>Data Pegawai </h2><hr />";
elseif($print == FALSE):
$nilai='<a href="'.base_url('admin/kelpeg2_print').'" class="btn btn-warning"><i class="fa fa-print"></i>Print Data Pegawai</a>
<br /><br /><br />';
endif;
echo $nilai;

?>
     

<form action="" method="POST" enctype="multipart/form-data">
    <tr>
	  <th>No</th>
      <th>Nip</th>
      <th>Nama Pegawai</th>
      <th>Nama Ayah</th>
	  <th>Tempat Ayah</th>
	  <th>Tanggal Lahir Ayah</th>
	  <th>Pekerjaan Ayah</th>
	  <th>Alamat Ayah</th>
	  <th>Nama Ibu</th>
	  <th>Tempat Ibu</th>
	  <th>Tanggal Lahir Ibu</th>
	  <th>Pekerjaan Ibu</th>
	  <th>Alamat Ibu</th>
	  <th>Nama Istri/Suami</th>
	  <th>Jenis Kelamin</th>
	  <th>Tempat Istri/Suami</th>
	  <th>Tanggal Lahir Istri/Suami</th>
	  <th>Tanggal Kawin</th>
	  <th>Pendidikan Akhir Istri/Suami</th>
	  <th>Pekerjaan Istri/Suami</th>
	  <th>Nip Istri/Suami</th>
	  <th>Pangkat Istri/Suami</th>
	  <th>No KK</th>
	  <th>NIK Istri/Suami</th>
	  <th>OPD</th>
	  <th>Nama Anak-1</th>
	  <th>Tempat Anak-1</th>
	  <th>Tanggal Lahir Anak-1</th>
	  <th>Pekerjaan Anak-1</th>
	  <th>Status Anak-1</th>
	  <th>Pendidikan Anak-1</th>
	  <th>Jenis Kelamin Anak-1</th>
	  <th>Nama Anak-2</th>
	  <th>Tempat Anak-2</th>
	  <th>Tanggal Lahir Anak-2</th>
	  <th>Pekerjaan Anak-2</th>
	  <th>Status Anak-2</th>
	  <th>Pendidikan Anak-2</th>
	  <th>Jenis Kelamin Anak-2</th>
	  <th>Nama Anak-3</th>
	  <th>Tempat Anak-3</th>
	  <th>Tanggal Lahir Anak-3</th>
	  <th>Pekerjaan Anak-3</th>
	  <th>Status Anak-3</th>
	  <th>Pendidikan Anak-3</th>
	  <th>Jenis Kelamin Anak-3</th>
      <th>Aksi</th>
    </tr>

     <tbody>
     <?php $no=1; foreach($data as $admin): ?>
     <tr>
     <td><?= $no ?></td>
	 <td><?= $admin['nip'] ?></td> 
     <td><?= $admin['nama'] ?></td> 
	 <td><?= $admin['nama_ayah'] ?></td>
	 <td><?= $admin['tempat_ayah'] ?></td>
	 <td><?= $admin['tgllahir_ayah'] ?></td>
	 <td><?= $admin['pekerjaan_ayah'] ?></td>
	 <td><?= $admin['alamat_ayah'] ?></td>
	 <td><?= $admin['nama_ibu'] ?></td>
	 <td><?= $admin['tempat_ibu'] ?></td>
	 <td><?= $admin['tgllahir_ibu'] ?></td>
	 <td><?= $admin['pekerjaan_ibu'] ?></td>
	 <td><?= $admin['alamat_ibu'] ?></td>
	 <td><?= $admin['nama_is'] ?></td>
     <td><?php if($admin['jk'] == "L"){ echo "Laki-Laki";}else{ echo "Perempuan";} ?></td>
	 <td><?= $admin['tempat_is'] ?></td>
	 <td><?= $admin['tgllahir_is'] ?></td>
	 <td><?= $admin['tglkawin'] ?></td>
	 <td><?= $admin['pendidikan_akhir_is'] ?></td>
     <td><?= $admin['pekerjaan_is'] ?></td>
	 <td><?= $admin['nip_is'] ?></td>
     <td><?= $admin['pangkat_is'] ?></td>
	 <td><?= $admin['nokk'] ?></td>
     <td><?= $admin['nik_is'] ?></td>
     <td><?= $admin['opd'] ?></td>
     <td><?= $admin['nama_anak1'] ?></td>
     <td><?= $admin['tempat_anak1'] ?></td>
	 <td><?= $admin['tgllahir_anak1'] ?></td>
	 <td><?= $admin['pekerjaan_anak1'] ?></td>
     <td><?= $admin['status_anak1'] ?></td>
	 <td><?= $admin['pendidikan_anak1'] ?></td>
	 <td><?= $admin['jk_anak1'] ?></td>
	 <td><?= $admin['nama_anak2'] ?></td>
     <td><?= $admin['tempat_anak2'] ?></td>
	 <td><?= $admin['tgllahir_anak2'] ?></td>
	 <td><?= $admin['pekerjaan_anak2'] ?></td>
     <td><?= $admin['status_anak2'] ?></td>
	 <td><?= $admin['pendidikan_anak2'] ?></td>
	 <td><?= $admin['jk_anak2'] ?></td>
	 <td><?= $admin['nama_anak3'] ?></td>
     <td><?= $admin['tempat_anak3'] ?></td>
	 <td><?= $admin['tgllahir_anak3'] ?></td>
	 <td><?= $admin['pekerjaan_anak3'] ?></td>
     <td><?= $admin['status_anak3'] ?></td>
	 <td><?= $admin['pendidikan_anak3'] ?></td>
	 <td><?= $admin['jk_anak3'] ?></td>
     </tr>
     <?php $no++; endforeach; ?>
     </tbody>
</form>
<td><a href="<?= base_url('admin/kelpeg_edit/'.$admin['id_pegawai']) ?>" class="btn btn-info">Edit</a></td> 
     

 
 