<a href="jabatan_form"> <button onClick="window.print();" class="btn btn-warning" >Print Data</button></a>
<table class="table table-reposive">
	<form action="" method="POST">
	<tr><th>Nama Pegawai</th><td><input type="text" name="nama_pegawai" class="form-control" value="<?= $nama_pegawai ?>"></td></tr>
	<tr><th>Nama Jabatan</th><td><input type="text" name="nama_jabatan" class="form-control" value="<?= $nama_jabatan ?>"></td></tr>
	<tr><th>Golongan</th><td><select class="form-control" name="golongan" required="">
	                          <option value="I/A">I/A</option>
	                          <option value="I/B">I/B</option>
							  <option value="I/C">I/C</option>
							  <option value="I/D">I/D</option>
							  <option value="II/A">II/A</option>
	                          <option value="II/B">II/B</option>
							  <option value="II/C">II/C</option>
							  <option value="II/D">II/D</option>
							  <option value="III/A">III/A</option>
	                          <option value="III/B">III/B</option>
							  <option value="III/C">III/C</option>
							  <option value="III/D">III/D</option>
							  <option value="IV/A">IV/A</option>
	                          <option value="IV/B">IV/B</option>
							  <option value="IV/C">IV/C</option>
							  <option value="IV/D">IV/D</option>
                              </select></td></tr>
	<tr><th>Jumlah Tunjangan</th><td><input type="number" name="tunjangan" class="form-control" value="<?= $tunjangan ?>"></td></tr>
    <tr><td></td><th><input type="submit" name="kirim" value="Submit" class="btn btn-primary"></th></tr>
    </form>	 
</table>
 
 