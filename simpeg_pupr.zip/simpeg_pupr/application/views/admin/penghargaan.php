<td><a href="<?= base_url('admin/penghargaan_tambah/') ?>" class="btn btn-primary">Tambah</a><a href="penghargaan"> <button onClick="window.print();" class="btn btn-warning" >Print Data</button></a></td>

<br /><br /><br />
<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
                  <th>Nama Pegawai</th>
				  <th>Nomor SK Penghargaan</th>
                  <th>Tanggal SK Penghargaan</th>
                  <th>Asal SK Penghargaan</th>
                  <th>Aksi</th>
                </tr>
                </thead>
                 <tbody>
                 <?php $no=1; foreach($data as $admin): ?>
                 <tr>
                 <td><?= $no ?></td>
				 <td><?= $admin['nama_pegawai'] ?></td>
                 <td><?= $admin['no_skpenghargaan'] ?></td> 
                 <td><?= $admin['tgl_skpenghargaan'] ?></td>
				 <td><?= $admin['asal_skpenghargaan'] ?></td>
                 <td><a href="<?= base_url('admin/penghargaan_edit/'.$admin['id_penghargaan']) ?>" class="btn btn-info">Edit</a> <a href="<?= base_url('admin/penghargaan_hapus/'.$admin['id_penghargaan']) ?>" class="btn btn-danger">Hapus</a></td> 
                 </tr>

                 <?php $no++; endforeach; ?>
                 
                 </tbody>
              </table>


 
 
 