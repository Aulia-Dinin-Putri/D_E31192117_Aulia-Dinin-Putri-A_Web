<td><a href="<?= base_url('admin/kelpeg_tambah/') ?>" class="btn btn-primary">Tambah</a> <a href="<?= base_url('export_peg') ?>"> <button class="btn btn-success" >Export to excel</button></a></td>
<br /><br /><br />
<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
    <thead>
    <tr>
	  <th>No</th>
      <th>Nip</th>
      <th>Nama Pegawai</th>
      <th>Aksi</th>
    </tr>
    </thead>
     <tbody>
     <?php $no=1; foreach($data as $admin): ?>
     <tr>
     <td><?= $no ?></td>
	 <td><?= $admin['nip'] ?></td> 
     <td><?= $admin['nama'] ?></td>
     <td><a href="<?= base_url('admin/kelpeg2/'.$admin['id_kelpeg']) ?>" class="btn btn-success">Detail Keluarga</a> <a href="<?= base_url('admin/kelpeg_hapus/'.$admin['id_pegawai']) ?>" class="btn btn-danger">Hapus</a></td> 
     </tr>
     <?php $no++; endforeach; ?>
     </tbody>
   </table>

 
 