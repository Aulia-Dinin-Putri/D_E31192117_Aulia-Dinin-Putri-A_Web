<?php
 if($this->session->userdata('level') == "admin" ){

 ?>
<!--<h1 class="h4 text-black-900 mb-4"><center><font size="5" face="Sunday Best">HOME</font></center></h1>-->

<br><br>
<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3>Pengangkatan Pegawai</h3>

              <p>Pengangkatan Pegawai (CPNS)</p>
            </div>
            <div class="icon">
              <i class="fa fa-cubes"></i>
            </div>
            <a href="http://localhost/simpeg_pupr/admin/pengangkatancpns" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3>Pengangkatan Pegawai</h3>

              <p>Pengangkatan Pegawai (PNS)</p>
            </div>
            <div class="icon">
             <i class="fa fa-cubes"></i>
            </div>
            <a href="http://localhost/simpeg_pupr/admin/pengangkatanpns" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

              <div class="chart">
                <canvas id="barChart" style="height:230px"></canvas>
              </div>
<?php } ?>