<table class="table table-reposive">
	<form action="" method="POST">
	<tr><th>Tanggal Persetujuan BAKN</th><td><input type="date" name="tgl_persetujuan_bakn" class="form-control" value="<?= $tgl_persetujuan_bakn ?>"></td></tr>
	<tr><th>Nama Pegawai</th><td><input type="text" name="nama" class="form-control" value="<?= $nama ?>"></td></tr>
	<tr><th>Nomor Nota Persetujuan BAKN</th><td><input type="text" name="no_nota_persetujuan_bakn" class="form-control" value="<?= $no_nota_persetujuan_bakn ?>"></td></tr>
	<tr><th>Pejabat yang menetapkan</th><td><select class="form-control" name="pejabat_ygmenetapkan" required="">
	                          <option value="A">A</option>
	                          <option value="B">B</option>
							  <option value="C">C</option>

	<tr><th>Nomor SK CPNS</th><td><input type="text" name="no_sk_cpns" class="form-control" value="<?= $no_sk_cpns ?>"></td></tr>
	<tr><th>Tanggal SK CPNS</th><td><input type="date" name="tgl_sk_cpns" class="form-control" value="<?= $tgl_sk_cpns ?>"></td></tr>
	<tr><th>Gaji</th><td><input type="text" name="gaji" class="form-control" value="<?= $gaji ?>"></td></tr>
	<tr><th>Ijazah</th><td><select class="form-control" name="ijazah" required="">
	                          <option value="SD/MI">SD/MI</option>
	                          <option value="SMP/MTS">SMP/MTS</option>
							  <option value="SMA/MA">SMA/MA</option>
							  <option value="D3">D3</option>
							  <option value="S1">S1</option>
	                          <option value="S2">S2</option>
	<tr><th>Tahun Ijazah</th><td><input type="text" name="ijazah_tahun" class="form-control" value="<?= $ijazah_tahun ?>"></td></tr>
	<tr><th>Golongan Ruang</th><td><select class="form-control" name="gol_ruang" required="">
	                          <option value="I/A">I/A</option>
	                          <option value="I/B">I/B</option>
							  <option value="I/C">I/C</option>
							  <option value="I/D">I/D</option>
							  <option value="II/A">II/A</option>
	                          <option value="II/B">II/B</option>
							  <option value="II/C">II/C</option>
							  <option value="II/D">II/D</option>
							  <option value="III/A">III/A</option>
	                          <option value="III/B">III/B</option>
							  <option value="III/C">III/C</option>
							  <option value="III/D">III/D</option>
							  <option value="IV/A">IV/A</option>
	                          <option value="IV/B">IV/B</option>
							  <option value="IV/C">IV/C</option>
							  <option value="IV/D">IV/D</option>
	<tr><th>T.M.T CPNS</th><td><input type="date" name="tmt_cpns" class="form-control" value="<?= $tmt_cpns ?>"></td></tr>
	<!--<tr><th>Tahun</th><td><input type="text" name="tahun" class="form-control" value="<?= $tahun ?>"></td></tr>-->
	<tr><th>Bulan</th><td><select class="form-control" name="bulan" required="">
	                          <option value="Januari">Januari</option>
	                          <option value="Februari">Februari</option>
							  <option value="Maret">Maret</option>
							  <option value="April">April</option>
							  <option value="Mei">Mei</option>
	                          <option value="Juni">Juni</option>
							  <option value="Juli">Juli</option>
							  <option value="Agustus">Agustus</option>
							  <option value="September">September</option>
	                          <option value="Oktober">Oktober</option>
							  <option value="November">November</option>
							  <option value="Desember">Desember</option></td></tr>
	<tr><th>Jabatan</th><td><input type="text" name="jabatan" class="form-control" value="<?= $jabatan ?>"></td></tr>
	<tr><th>OPD</th><td><input type="text" name="opd" class="form-control" value="<?= $opd ?>"></td></tr>
	<tr><th>T.M.T SPMT</th><td><input type="date" name="tmt_spmt" class="form-control" value="<?= $tmt_spmt ?>"></td></tr>
	<tr><th>Tahun + MK</th><td><input type="teks" name="tahun_tambah_mk" class="form-control" value="<?= $tahun_tambah_mk ?>"></td></tr>
	<tr><th>Bulan + MK</th><td><select class="form-control" name="bulan_tambah_mk" required="">
	                          <option value="Januari">Januari</option>
	                          <option value="Februari">Februari</option>
							  <option value="Maret">Maret</option>
							  <option value="April">April</option>
							  <option value="Mei">Mei</option>
	                          <option value="Juni">Juni</option>
							  <option value="Juli">Juli</option>
							  <option value="Agustus">Agustus</option>
							  <option value="September">September</option>
	                          <option value="Oktober">Oktober</option>
							  <option value="November">November</option>
							  <option value="Desember">Desember</option></td></tr>
    <tr><td></td><td><input type="submit" name="kirim" value="Submit" class="btn btn-primary"> &nbsp;&nbsp;<input type="reset" name="g" value="Batal" class="btn btn-danger"></td></tr>
	</form>	 
</table>
 
 