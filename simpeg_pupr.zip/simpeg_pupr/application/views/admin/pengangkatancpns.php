<a href="<?= base_url('admin/pengangkatancpns_tambah/') ?>" class="btn btn-primary">Tambah</a>
<br /><br /><br />
<?= $this->session->flashdata('pesan') ?>
 <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>No</th>
				  <!--<th>Tanggal Persetujuan BAKN</th>-->
                  <th>Nama Pegawai</th>
				  <!--<th>Nomor Nota Persetujuan BAKN</th>
                  <th>Pejabat yang menetapkan</th>
                  <th>Nomor SK CPNS</th>
				  <th>Tanggal SK CPNS</th>-->
				  <th>Gaji</th>
				  <!--<th>Ijazah</th>
				  <th>Tahun Ijazah</th>-->
				  <th>Gol Ruang</th>
				  <th>T.M.T CPNS</th>
				  <!--<th>Tahun</th>
				  <th>Bulan</th>-->
				  <th>Jabatan</th>
				  <th>OPD</th>
				  <!--<th>T.M.T SPMT</th>
				  <th>Tahun + MK</th>
				  <th>Bulan + MK</th>-->
                  <th>Aksi</th>
                </tr>
                </thead>
                 <tbody>
                 <?php $no=1; foreach($data as $admin): ?>
                 <tr>
                 <td><?= $no ?></td>
				 <!--<td><?= $admin['tgl_persetujuan_bakn'] ?></td>-->
				 <td><?= $admin['nama'] ?></td>
                 <!--<td><?= $admin['no_nota_persetujuan_bakn'] ?></td> 
                 <td><?= $admin['pejabat_ygmenetapkan'] ?></td>
				 <td><?= $admin['no_sk_cpns'] ?></td>
				 <td><?= $admin['tgl_sk_cpns'] ?></td>-->
				 <td><?= $admin['gaji'] ?></td>
				 <!--<td><?= $admin['ijazah'] ?></td>
				 <td><?= $admin['ijazah_tahun'] ?></td>-->
				 <td><?= $admin['gol_ruang'] ?></td>
				 <td><?= $admin['tmt_cpns'] ?></td>
				 <!--<td><?= $admin['tahun'] ?></td>
				 <td><?= $admin['bulan'] ?></td>-->
				 <td><?= $admin['jabatan'] ?></td>
				 <td><?= $admin['opd'] ?></td>
				 <!--<td><?= $admin['tmt_spmt'] ?></td>
				 <td><?= $admin['tahun_tambah_mk'] ?></td>
				 <td><?= $admin['bulan_tambah_mk'] ?></td>-->
                 <td><a href="<?= base_url('admin/pengangkatancpns_edit/'.$admin['id_angkat_cpns']) ?>" class="btn btn-info">Edit</a> <a href="<?= base_url('admin/pengangkatancpns_hapus/'.$admin['id_angkat_cpns']) ?>" class="btn btn-danger">Hapus</a></td> 
                 </tr>

                 <?php $no++; endforeach; ?>
                 
                 </tbody>
              </table>


 
 
 