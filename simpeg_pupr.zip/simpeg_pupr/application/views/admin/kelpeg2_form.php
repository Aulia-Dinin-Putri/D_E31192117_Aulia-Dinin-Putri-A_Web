<table class="table table-striped">
<form action="" method="POST" enctype="multipart/form-data"> 
 
<tr><th>Nip</th><td><input type="number" name="nip" value="<?= $nip ?>" class="form-control" required=""></td></tr>
<tr><th>Nama Pegawai</th><td><input type="text" name="nama" value="<?= $nama ?>" class="form-control" required=""></td></tr>

<tr><th>Username</th><td><input type="text" name="username" value="<?= $username ?>" class="form-control" required=""></td></tr>
<?php
	$disabled = "";
	if($aksi == "edit"){
		$disabled = "disabled";
	}
?>
<tr><th>Password</th><td><input type="password" name="password" value="" class="form-control" <?= $disabled;?>></td></tr>
<tr><td></td><td><input type="submit" name="kirim" value="Submit" class="btn btn-primary"> &nbsp;&nbsp;<input type="reset" name="g" value="Batal" class="btn btn-danger"></td></tr>

</form>
</table>
<?php 
if($aksi == "edit"):
?>	
<span><i></i></span>
<?php endif; ?>