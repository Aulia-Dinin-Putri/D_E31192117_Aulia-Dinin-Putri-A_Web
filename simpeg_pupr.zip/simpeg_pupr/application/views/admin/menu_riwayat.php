<?php
 if($this->session->userdata('level') == "admin" ){

 ?>
<!--<h1 class="h4 text-black-900 mb-4"><center><font size="5" face="Sunday Best">HOME</font></center></h1>-->

<br><br>
<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-yellow">
            <div class="inner">
              <h3></h3>

              <p>Riwayat Pengangkatan Pegawai</p>
            </div>
            <div class="icon">
              <i class="fa fa-book"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/menu_pengangkatan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>
		
<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-red">
            <div class="inner">
              <h3></h3>

              <p>Riwayat Penghargaan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-book"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/penghargaan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-green">
            <div class="inner">
              <h3></h3>

              <p>Riwayat Jabatan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-book"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/penghargaan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-blue">
            <div class="inner">
              <h3></h3>

              <p>Riwayat Pendidikan Pegawai</p>
            </div>
            <div class="icon">
             <i class="fa fa-book"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/penghargaan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

<div class="col-lg-8 col-xs-16">
          <!-- small box -->
          <div class="small-box bg-white">
            <div class="inner">
              <h3></h3>

              <p>Riwayat Diklat Struktural Pegawai</p>
			</div>
            <div class="icon">
             <i class="fa fa-book"></i>
            </div>
            <a href="http://localhost/simpeg_SI/admin/penghargaan" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
          </div>
        </div>

              <div class="chart">
                <canvas id="barChart" style="height:230px"></canvas>
              </div>
<?php } ?>